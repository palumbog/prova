//
//  TextCell.swift
//  DrugBox
//
//  Created by giuseppe palumbo on 03/09/2017.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit

class TextCell: UITableViewCell {

    
    @IBOutlet weak var testoLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
