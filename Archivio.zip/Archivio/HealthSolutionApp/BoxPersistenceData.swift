//
//  BoxPersistenceData.swift
//  HealthSolutionApp
//
//  Created by Alberto Capriolo on 02/03/2017.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//


import Foundation
import CoreData
import UIKit

class BoxPersistenceData {
    static let name =  "Box"
    static func getContext() -> NSManagedObjectContext{
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        return appDelegate.persistentContainer.viewContext
        
    }
    
    static func newEmptyItem (code: String) -> Box {
        let context = getContext()
        
        let pBox = NSEntityDescription.insertNewObject(forEntityName: name, into: context) as! Box
        var pDrug = DrugPersistenceData.searchDrug(code: code)
        if pDrug != nil{
            print("Found in local")
        }else{
            print("Do with web services")
            pDrug = DrugPersistenceData.newEmptyItem(code: code)
        }
        
        
        pBox.dateExpiring = Date() as NSDate?
        pBox.quanitityRemaining = 0
        pBox.drug = pDrug
        //pDrug.categoryDrug = "newCategory"
        
        return pBox
    }
    
    static func newItem (dateExpiring: Date,drug: Drug,quanitityRemaining: Int16 ) -> Box {
        let context = getContext()
        
        let pBox = NSEntityDescription.insertNewObject(forEntityName: name, into: context) as! Box
        
        
        pBox.dateExpiring = dateExpiring as NSDate?
        pBox.quanitityRemaining = quanitityRemaining
        pBox.drug = drug
        //pDrug.categoryDrug = "newCategory"
        
        return pBox
    }

    
    static func fetchData() -> [Box]{
        var items = [Box]()
        
        let context = getContext()
        
        let fetchRequest =  NSFetchRequest<Box>(entityName: name)
        //fetchRequest.predicate(drug = drug e quantità > 0)
        do{
            try items = context.fetch(fetchRequest)
        }catch let error as NSError{
            print("Errore in fetch \(error.code) ")
        }
        return items
    }
    
    static func saveContext(){
        let context = getContext()
        
        do{
            try context.save()
        }catch let error as NSError{
            print("Errore in salvataggio \(error.code) ")
        }
        
    }
    
    static func deleteContext(item: Box){
        let context = getContext()
        
        do{
            try context.delete(item)
        }catch let error as NSError{
            print("Errore in cancellazione \(error.code) ")
        }
    }
}
