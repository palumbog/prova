//
//  OnlineController.swift
//  DrugBox
//
//  Created by gpalumbo on 30/06/17.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit
import Firebase

class OnlineController: NSObject {

    let ref: DatabaseReference = Database.database().reference()
    
    var sharedDrugs : [Farmaco] = []
    var users = [String]()
    
    override init(){
        super.init()
    }
    
    
    //Osservo quando viene aggiunto un farmaco nella mia zona
    func observeDrugsPlace(zona : String){
        //Mi prendo tutto il nodo farmaci quando avviene un cambiamento ad uno dei sottonodi
        ref.child("farmaci").observe(.value, with: { (snapshot) in
            // Get user value
            let value = snapshot.value as? NSDictionary
            //Value è un dizionario con numero di elementi uguale al numero di farmaci in database
            //con chiave i codici dei farmaci e valori un dizionario chiave-valore
            
            //Recuperiamo tutte le chiavi
            let keys = value?.allKeys as! [String]
            self.sharedDrugs.removeAll()
            
            for key in keys {
                let dic = value?["\(key)"] as! NSDictionary
                
                let drug = Farmaco(code: (dic["codice"])! as! String, nome: (dic["nome"])! as! String, ditta: (dic["casa"])! as! String, principio: (dic["principio"])! as! String,quantita: (dic["quantita"])! as! Int16)
                //let drug : Drug = self.createDrug(code: (dic["codice"])! as! String, nameDrug: (dic["nome"])! as! String, quantityDrug: (dic["quantita"])! as! Int16, activePrincipeDrug: (dic["principio"])! as! String, drugmakerDrug: (dic["casa"])! as! String)
                
                self.sharedDrugs.append(drug)
                
            }
        }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    //Osservo gli utenti che hanno condiviso un farmaco
    func observeUsers(codice: String) {
        ref.child("farmaciusers").observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user value
            let value = snapshot.value as? NSDictionary
            //Value è un dizionario con numero di elementi uguale al numero di farmaci condivisi
            
            
            //Recuperiamo tutte le chiavi
            let keys = value?.allKeys as! [String]
            if(keys.contains(codice)){
                print("Ci sono utenti che hanno quel farmaco")
                var keyUsers = value?[codice] as? NSDictionary
                self.users = keyUsers?.allKeys as! [String]
            }
            else{
                print("Non ci sono utenti che hanno quel farmaco")
            }
        }
            
            
        ) { (error) in
            print(error.localizedDescription)
        }
    }
    
    
     func insertDrug(drug : Drug){
        
        
        ref.child("farmaci").child(drug.codeDrug!).setValue([
            
            "codice" : drug.codeDrug!,
            
            "nome" : drug.nameDrug!,
            
            "principio" : drug.activePrincipeDrug!,
            
            "casa" : drug.drugmakerDrug!,
            
            "quantita" : drug.quantityDrug
            
            ])
    }
    
}
