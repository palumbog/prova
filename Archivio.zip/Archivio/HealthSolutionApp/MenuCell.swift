//
//  MenuCell.swift
//  DrugBox
//
//  Created by giuseppe palumbo on 23/08/2017.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit

class MenuCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
}
