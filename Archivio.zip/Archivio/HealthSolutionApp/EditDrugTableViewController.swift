//
//  EditDrugTableViewController.swift
//  HealthSolutionApp
//
//  Created by Alberto Capriolo on 05/03/2017.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit

class EditDrugTableViewController: UITableViewController {

    var box: Box?
    var onlineManager : FirebaseManager?
    var manager : DataManager?
    
    @IBOutlet weak var expiringText: UITextField!
    
    @IBOutlet weak var sharedSwitch: UISwitch!
    @IBOutlet weak var barcodeText: UITextField!
    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var quantityText: UITextField!
    @IBOutlet weak var reminderSwitch: UISwitch!
    @IBOutlet weak var descriptionText: UITextField!
    @IBOutlet weak var drugmakerText: UITextField!
    @IBOutlet weak var imageDrug: UIImageView!
    
    @IBOutlet weak var section1_1: UITableViewCell!
    @IBOutlet weak var section2_1: UITableViewCell!
    @IBOutlet weak var section2_2: UITableViewCell!
    @IBOutlet weak var section2_3: UITableViewCell!
    @IBOutlet weak var section2_4: UITableViewCell!
    @IBOutlet weak var section3_1: UITableViewCell!
    @IBOutlet weak var section3_2: UITableViewCell!
    @IBOutlet weak var section4_1: UITableViewCell!
    var user : User?
    
    @IBAction func aggiungiScatolo(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        
        //xlet aggiungiController = storyboard?.instantiateViewController(withIdentifier: "AddDrug") as! AddDrugTableViewController
        
        var storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        // It is instance of  `NewViewController` from storyboard
        var vc : lol = storyboard.instantiateViewController(withIdentifier: "Lol") as! lol
        // Pass delegate and variable to vc which is NewViewController
       
        
        
        
        
        //aggiungiController.barcodeText.text = box?.drug?.codeDrug
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    func changeStateSection(_ x: Bool){
        expiringText.isEnabled = x
        nameText.isEnabled = x
        quantityText.isEnabled = x
        drugmakerText.isEnabled = x
        descriptionText.isEnabled = x
        
        // NUOVO
        barcodeText.isEnabled = x
    }
    
    
    @IBAction func sharedSwitchPressed(_ sender: Any) {
        
        switch sharedSwitch.isOn{
        case true:
            guard (user != nil) else{
                self.navigationController?.view.makeToast("Devi creare il profilo per condividere")
                sharedSwitch.isOn = false
                return
            }
            onlineManager?.insertDrug(drug: (box?.drug)!)
            onlineManager?.insertBox(drugCode: (self.box?.drug?.codeDrug)!, dateExpiring: (self.box?.dateExpiring)!, quantityRemaining: Int((self.box?.quanitityRemaining)!), nickname: (user?.nickname!)!)
            onlineManager?.insertZonaFarmaci(zona: (user?.provincia!)!, drugCode: (self.box?.drug?.codeDrug)!)
            self.navigationController?.view.makeToast("Farmaco condiviso")
        case false:
            guard (user != nil) else{
                self.navigationController?.view.makeToast("Devi creare il profilo per condividere")
                sharedSwitch.isOn = false
                return
            }
            onlineManager?.deleteBox(drugCode: (box?.drug?.codeDrug)!, nickname: (user?.nickname)!,boxCode : (box?.sharedKey)!, zona: (user?.provincia)!)
            box?.shared = false
            manager?.saveContext()
            self.navigationController?.view.makeToast("Farmaco non condiviso")
        }
    }

    
    
    func setLabels() {
        
        
        
        nameText.text = (box?.drug?.nameDrug)!
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        let date = dateFormatter.string(from: self.box?.dateExpiring! as! Date)
        expiringText.text = date
        let quantity = "\((box?.quanitityRemaining)!)"
        quantityText.text = quantity
        descriptionText.text = (box?.drug?.activePrincipeDrug)!
        drugmakerText.text = (box?.drug?.drugmakerDrug)!
        sharedSwitch.isOn = (box?.shared)!
        reminderSwitch.isOn = false
        barcodeText.text = (box?.drug?.codeDrug)!
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        user = manager?.getUser()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        navigationItem.title = box?.drug?.nameDrug
        setLabels()
        
        if (manager?.boxScaduto(box: box!))!{
            sharedSwitch.isEnabled = false
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(insertCodeBox(_:)), name: NSNotification.Name(rawValue: "CodeBox") , object: nil)
        
        changeStateSection(false)
        
        
        
        /*
        let editBtn = UIBarButtonItem(barButtonSystemItem: .edit, target: nil, action: #selector(editPressed))
        
         self.navigationItem.rightBarButtonItem = editBtn
         */
        }
    
    func insertCodeBox(_ notification: NSNotification){
        if let code = notification.userInfo?["code"] as? String{
            box?.sharedKey = code
            box?.shared = true
            manager?.saveContext()
        }
        
    }
    
    
    //NUOVO
    var show = true
    
    func editPressed(lol : Int){
        print("LOL")
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source
    /*
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 0
    }*/

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation
/*
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        switch segue.identifier {
        case "editDrug"?:
            print("prova edit")
            
        default:
            preconditionFailure("Segue non valido.")
        }
    }
*/

}
