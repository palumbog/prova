//
//  DataManager.swift
//  DrugBox
//
//  Created by gpalumbo on 30/06/17.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit
import Foundation
import CoreData


class DataManager: NSObject {
    
    static let sharedInstance = DataManager()
    
    
    func createDrug (code: String,nameDrug: String,quantityDrug: Int16,activePrincipeDrug: String,drugmakerDrug: String,typeDrug : String) -> Drug {
        
        let pDrug = self.newDrug()
        
        pDrug.codeDrug = code
        pDrug.nameDrug = nameDrug
        pDrug.activePrincipeDrug = activePrincipeDrug
        pDrug.drugmakerDrug = drugmakerDrug
        pDrug.quantityDrug = quantityDrug
        pDrug.typeDrug = typeDrug
        self.saveContext()
        return pDrug
    }
    
    //DRUG HELPER
    
    //Ritorna la quantità totale di tutte le pillole degli scatoli di un farmaco
    func getTotalQuantityDrug(drug : Drug,conScaduti: Bool = false) -> Int16{
        var quantity : Int16
        quantity = 0
        let boxes = getAllBoxes(by: DataManager.Case.code.rawValue, info: drug.codeDrug!)
        for box in boxes {
            if(conScaduti){
                quantity = quantity + box.quanitityRemaining
            }else{
                if(!boxScaduto(box: box)){
                    quantity = quantity + box.quanitityRemaining
                }
            }
        }
        return quantity
    }
    
    
    //Conta numero di scatoli di un farmaco
    func getNumBoxesDrug(drug : Drug,conScaduti: Bool = false) -> Int{
        var count = 0
        let boxes = getAllBoxes(by:DataManager.Case.code.rawValue, info: drug.codeDrug!)
        if(conScaduti){
            return boxes.count
        }
        else{
            for box in boxes{
                if(!boxScaduto(box: box)){
                    count += 1
                }
            }
        }
        return count
    }
    
    
    //Se non passiamo alcun valore a questa funzione  il valore di default è false
    func getAllDrugs(by : Int = 0,info : String = "",orderedBy: Int = 0,withBox:Bool=false) -> [Drug] {
        
        var items = [Drug]()
        
        let fetchRequest =  NSFetchRequest<Drug>(entityName: "Drug")
        
        
        var byPredicate = NSPredicate(value: true)
        
        switch by {
        case Case.name.rawValue :
            byPredicate = NSPredicate(format: "nameDrug = %@",info)
        case Case.code.rawValue :
            byPredicate = NSPredicate(format: "codeDrug = %@", info)
        case Case.activePrinciple.rawValue :
            byPredicate = NSPredicate(format: "activePrincipeDrug = %@",info)
        case Case.containName.rawValue :
            byPredicate = NSPredicate(format: "nameDrug contains[c] %@",info)
        case Case.containActivePrinciple.rawValue :
            byPredicate = NSPredicate(format: "activePrincipeDrug contains[c] %@",info)
        default : break
        }
        
        if (withBox ){
            let withBoxPredicate = NSPredicate(format: "boxes.@count > 0")
            fetchRequest.predicate = NSCompoundPredicate(type: NSCompoundPredicate.LogicalType.and, subpredicates: [byPredicate, withBoxPredicate])
        }else{
            fetchRequest.predicate = byPredicate
        }
        
        do{
            try items = self.persistentContainer.viewContext.fetch(fetchRequest)
        }catch let error as NSError{
            print("Error during fetching \(error.code) ")
        }
        
        
        switch orderedBy {
        case DrugOrder.nameDisc.rawValue :
            return items.sorted(by: sorterDrugsByNameDisc)
        case DrugOrder.nameAsc.rawValue :
            return items.sorted(by: sorterDrugsByNameAsc)
        case DrugOrder.activePrincipleDisc.rawValue :
            return items.sorted(by: sorterDrugsByActivePrincipleDisc)
        case DrugOrder.activePrincipleAsc.rawValue :
            return items.sorted(by: sorterDrugsByActivePrincipleAsc)
        default : break
        }
        
        return items
        
    }
    
    func getDrugsWithNotExpiredBox() -> [Drug]{
        var items = [Drug]()
        
        let fetchRequest =  NSFetchRequest<Drug>(entityName: "Drug")
        let withBoxPredicate = NSPredicate(format: "boxes.@count > 0")
        fetchRequest.predicate = withBoxPredicate
        do{
            try items = self.persistentContainer.viewContext.fetch(fetchRequest)
        }catch let error as NSError{
            print("Error during fetching \(error.code) ")
        }
        //Elimino i farmaci con associati tutti scatoli scaduti
        if(items.count > 0){
            var i = 0
            
            for drug in items{
                if(allBoxesExpired(drug : drug)){
                    items.remove(at: i)
                    i -= 1
                }
                i += 1
            }
            
        }
        return items.sorted(by: sorterDrugsByNameDisc)
    }
    
    
    func allBoxesExpired(drug : Drug) -> Bool{
        
        let array = Array(drug.boxes!) as! [Box]
        
        for box in array{
            print(box.dateExpiring)
            if(!boxScaduto(box: box)){
                print("Non Scaduto")
                return false
            }
        }
        return true
    }
    
    //Restituisce un array con tutti i principi attivi
    func getActivePrinciple() -> NSArray{
        
        var items = NSArray()
        let fetchRequest =  NSFetchRequest<Drug>(entityName: "Drug")
        fetchRequest.propertiesToFetch = ["activePrincipeDrug"]
        fetchRequest.resultType = NSFetchRequestResultType.dictionaryResultType
        fetchRequest.returnsDistinctResults = true
        
        do{
            try items = self.persistentContainer.viewContext.fetch(fetchRequest as! NSFetchRequest<NSFetchRequestResult>) as NSArray
        }catch let error as NSError{
            print("Error during fetching \(error.code) ")
        }
        
        
        return items
    }
    
    
    
    //END
    
    
    public enum Case : Int{
        case all                    = 0
        case name                   = 1
        case code                   = 2
        case activePrinciple        = 3
        case containActivePrinciple = 4
        case containName            = 5
        case scaduti                = 6
        case nonScaduti             = 7
    }
    
    public enum DrugOrder : Int{
        case def                 = 0
        case nameDisc            = 1
        case nameAsc             = 2
        case activePrincipleDisc = 3
        case activePrincipleAsc  = 4
    }
    
    public enum BoxOrder : Int{
        case def          = 0
        case dataDisc     = 1
        case dataAsc      = 2
        case quantitaDisc = 3
        case quantitaAsc  = 4
    }
    
    //BOX HELPER
    
    func boxExpiringYear(box : Box) -> Bool{
        let calendar = NSCalendar.current
        let new = calendar.date(byAdding: Calendar.Component.year, value: 1, to: NSDate() as Date, wrappingComponents: false)
        
        var date = box.dateExpiring?.compare(new as! Date)
        return date == ComparisonResult.orderedAscending
        
    }
    
    func addBoxToDrug (theDrug:Drug , dateExpiring: NSDate, quantityRemaining: Int,shared: Bool,sharedKey : String = "") -> Bool {
        
        let theBox = self.newBox()
        
        theBox.dateExpiring         =   dateExpiring
        theBox.quanitityRemaining   =   Int16(quantityRemaining)
        
        theBox.shared = shared
        theBox.sharedKey = sharedKey
        theDrug.boxes?.adding(theBox)
        
        theBox.drug = theDrug
        
        self.saveContext()
        
        return true
        
    }
    
    //Ritorna tutti gli scatoli..by significa che trov gli scatoli per nome,codice,principio attivo e info è la stringa da cercare
    func getAllBoxes(by : Int = 0,info : String = "",orderedBy: Int = 0) -> [Box] {
        var items = [Box]()
        
        let fetchRequest =  NSFetchRequest<Box>(entityName: "Box")
        
        switch by {
        //nome
        case Case.name.rawValue:
            fetchRequest.predicate = NSPredicate(format: "drug.nameDrug = %@",info)
        //codice
        case Case.code.rawValue :
            fetchRequest.predicate = NSPredicate(format: "drug.codeDrug = %@",info)
        //principio attivo
        case Case.activePrinciple.rawValue:
            fetchRequest.predicate = NSPredicate(format: "drug.activePrincipeDrug = %@",info)
        //continene stringa in principio attivo
        case Case.containActivePrinciple.rawValue:
            fetchRequest.predicate = NSPredicate(format: "drug.activePrincipeDrug contains[c] %@",info)
        //contiene stringa nel nome
        case Case.containName.rawValue:
            fetchRequest.predicate = NSPredicate(format: "drug.nameDrug contains[c] %@",info)
        case Case.scaduti.rawValue :
            fetchRequest.predicate = NSPredicate(format: "dateExpiring < %@",NSDate())
        case Case.nonScaduti.rawValue :
            fetchRequest.predicate = NSPredicate(format: "dateExpiring > %@",NSDate())
        default: break
        }
        
        do{
            try items = self.persistentContainer.viewContext.fetch(fetchRequest)
        }catch let error as NSError{
            print("Error during fetching \(error.code) ")
        }
        
        switch orderedBy {
        case BoxOrder.dataDisc.rawValue:
            return items.sorted(by: sorterBoxByDateDisc)
        case BoxOrder.dataAsc.rawValue:
            return items.sorted(by: sorterBoxByDateAsc)
        case BoxOrder.quantitaDisc.rawValue:
            return items.sorted(by: sorterBoxByQuantitaDisc)
        case BoxOrder.quantitaAsc.rawValue:
            return items.sorted(by: sorterBoxByQuantitaAsc)
        default:
            break
        }
        
        return items
        
    }
    
    //Ritorna array di scatoli condivisi
    func getSharedBoxes() -> [Box]{
        var items = [Box]()
        
        let fetchRequest =  NSFetchRequest<Box>(entityName: "Box")
        
        fetchRequest.predicate = NSPredicate(format: "shared == %@", NSNumber(booleanLiteral: true))
        
        
        do{
            try items = self.persistentContainer.viewContext.fetch(fetchRequest)
        }catch let error as NSError{
            print("Error during fetching \(error.code) ")
        }
        return items
    }
    
    func boxScaduto(box : Box) -> Bool {
        var date = box.dateExpiring?.compare(NSDate() as Date)
        return date == ComparisonResult.orderedAscending || date == ComparisonResult.orderedSame
    }
    
    
    func decrementaQuantitaBoxUno(box : Box) -> Bool{
        let a = box.quanitityRemaining-1
        if(a>0){
            box.quanitityRemaining = a
            return true
        }else if(a == 0){
            deleteContext(item: box)
            return true
        }else{
            return false
        }
    }
    
    func decrementaQuantitaBox(box : Box,quantita : Int) -> Bool{
        let a = box.quanitityRemaining-quantita
        if(a < 0){
            return false
        }else if (a > 0){
            box.quanitityRemaining = a
        }else{
            deleteContext(item: box)
        }
        return true
    }
    //END
    
    //USER HELPER
    func getUser() -> User? {
        var user = [User]()
        
        let fetchRequest =  NSFetchRequest<User>(entityName: "User")
        
        do{
            try user = self.persistentContainer.viewContext.fetch(fetchRequest)
        }catch let error as NSError{
            print("Error during fetching \(error.code) ")
        }
        if (user.count == 0){
            return nil
        }
        return user[0]
    }
    
    func createUser(nickname: String,provincia : String) -> Bool{
        
        if(deletePreviousUser()){
            let user = newUser()
            user.nickname = nickname
            user.provincia = provincia
            self.saveContext()
            return true
        }
        return false
    }
    
    func deletePreviousUser() -> Bool {
        let fetchRequest = NSFetchRequest<User>(entityName: "User")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest as! NSFetchRequest<NSFetchRequestResult>)
        
        do {
            try self.persistentContainer.viewContext.execute(deleteRequest)
            return true
        } catch let error as NSError {
            // TODO: handle the error
            print(error)
            return false
        }
    }
    
    
    //SORT HELPER
    
    //DRUG SORT
    func sorterDrugsByNameDisc(d1: Drug,d2 : Drug) -> Bool{
        return (d1.nameDrug)! < (d2.nameDrug)!
    }
    func sorterDrugsByNameAsc(d1: Drug,d2 : Drug) -> Bool{
        return (d1.nameDrug)! > (d2.nameDrug)!
    }
    
    func sorterDrugsByActivePrincipleDisc(d1: Drug,d2 : Drug) -> Bool{
        return (d1.activePrincipeDrug)! < (d2.activePrincipeDrug)!
    }
    func sorterDrugsByActivePrincipleAsc(d1: Drug,d2 : Drug) -> Bool{
        return (d1.activePrincipeDrug)! > (d2.activePrincipeDrug)!
    }
    
    
    //BOX SORT
    func sorterBoxByDateDisc(b1: Box,b2 : Box) -> Bool{
        return b1.dateExpiring?.compare(b2.dateExpiring! as Date) == ComparisonResult.orderedDescending
    }
    func sorterBoxByDateAsc(b1: Box,b2 : Box) -> Bool{
        return b1.dateExpiring?.compare(b2.dateExpiring! as Date) == ComparisonResult.orderedAscending
    }
    func sorterBoxByQuantitaDisc(b1: Box,b2 : Box) -> Bool{
        return b1.quanitityRemaining > b2.quanitityRemaining
    }
    func sorterBoxByQuantitaAsc(b1: Box,b2 : Box) -> Bool{
        return b1.quanitityRemaining < b2.quanitityRemaining
    }
    func sorterBoxByName(b1: Box,b2 : Box) -> Bool{
        return (b1.drug?.nameDrug)! < (b2.drug?.nameDrug)!
    }
    
    
    //END SORT HELPER
    
    
    
    //CORE DATA HELPER
    func newDrug ()-> Drug {
        
        return NSEntityDescription.insertNewObject(forEntityName: "Drug", into: self.persistentContainer.viewContext) as! Drug
        
        
    }
    
    func newBox ()-> Box {
        
        return NSEntityDescription.insertNewObject(forEntityName: "Box", into: self.persistentContainer.viewContext) as! Box
        
    }
    
    func newUser ()-> User {
        
        return NSEntityDescription.insertNewObject(forEntityName: "User", into: self.persistentContainer.viewContext) as! User
        
    }
    
    
    
    // MARK: - Core Data stack
    
    lazy var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
         */
        let container = NSPersistentContainer(name: "HealthSolutionApp")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    // MARK: - Core Data Saving support
    
    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    func deleteContext(item: Any){
        let context = persistentContainer.viewContext
        
        do{
            try context.delete(item as! NSManagedObject)
        }catch let error as NSError{
            print("Errore in cancellazione \(error.code) ")
        }
    }
    
}
