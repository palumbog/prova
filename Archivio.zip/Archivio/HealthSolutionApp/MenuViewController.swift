import UIKit




class MenuViewController: UICollectionViewController {
    
    @IBOutlet weak var menuCollection: UICollectionView!
    
    let reuseIdentifier = "menuCell" // also enter this string as the cell identifier in the storyboard
    var items = ["I miei farmaci","Terapie", "Miei farmaci online", "Farmaci Online","Chat", "Profilo"]
    
    var mieiFarmaciViewController: UIViewController!
    var mieiFarmaciOnlineController: UIViewController!
    var farmaciOnlineViewController: UIViewController!
    var profiloViewController: UIViewController!
    var sharedViewController: UIViewController!
    var chatViewController: UIViewController!
    
    
    override func viewDidLoad() {
        
        
        
        super.viewDidLoad()
        //setupCell()
        collectionView?.backgroundColor = UIColor.clear
        view.backgroundColor = UIColor(colorLiteralRed: 10/255, green: 150/255, blue: 240/255, alpha: 1)
        collectionView?.register(MenuCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        navigationItem.title = "DrugBox"
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let mieiFarmaciViewController = storyboard.instantiateViewController(withIdentifier: "DrugList") as! DrugsViewController
        self.mieiFarmaciViewController = mieiFarmaciViewController
        
        let profiloViewController = storyboard.instantiateViewController(withIdentifier: "ProfiloViewController") as! ProfileViewController
        self.profiloViewController = profiloViewController
        
        let sharedViewController = storyboard.instantiateViewController(withIdentifier: "SharedView") as! SharedViewController
        self.sharedViewController = sharedViewController
        
        let chatViewController = storyboard.instantiateViewController(withIdentifier: "ChatView") as! ChatViewController
        self.chatViewController = chatViewController
        
    }
    
    // MARK: - UICollectionViewDataSource protocol
    
    // tell the collection view how many cells to make
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.items.count
    }
    
    // make a cell for each cell index path
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! MenuCell
        
        cell.layer.borderColor = UIColor.black.cgColor
        cell.layer.borderWidth = 1
        cell.layer.cornerRadius = 20
        
        switch indexPath.row {
        case 0:
            
            loadImage(cell)
                default:
            break
        }
        
        // Use the outlet in our custom class to get a reference to the UILabel in the cell
        
        cell.backgroundColor = UIColor(red: 47/255, green: 122/255, blue: 255/255, alpha: 1) // make cell more visible in our example project
        return cell
    }
    
    private func loadImage(_ cell: MenuCell){
        let im = #imageLiteral(resourceName: "Day")
        print(im.size)
                
    }
    
    @objc private func cellPressed(){
        print("You selected cell ")
    }

    override func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        print("Highlighted")
        let cell = collectionView.cellForItem(at: indexPath)
        cell?.backgroundColor = UIColor(red: 10/255, green: 122/255, blue: 255/255, alpha: 0)
    }
    
    // change background color back when user releases touch
    override func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath)
        cell?.backgroundColor = UIColor(red: 47/255, green: 122/255, blue: 255/255, alpha: 1)
    }
    
    // MARK: - UICollectionViewDelegate protocol
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // handle tap events
        if let menu = LeftMenu(rawValue: indexPath.row) {
            self.changeViewController(menu)
        }
        
        
    }
    /*
    private func setLabel(label : UILabel) -> UILabel{
        
    }*/
    
    func changeViewController(_ menu : LeftMenu){
        switch menu {
        case .farmaci:
            
                
            print("Miei Farmaci")
            self.navigationController?.pushViewController(self.mieiFarmaciViewController, animated: true)
        case .farmaciCondivisi:
            print("Miei Farmaci Condivisi")
        //self.slideMenuController()?.changeMainViewController(self.swiftViewController, close: true)
        case .online:
            print("Farmaci Online")
            self.navigationController?.pushViewController(self.sharedViewController, animated: true)
            
        case .profilo:
            print("Profilo")
            self.navigationController?.pushViewController(self.profiloViewController, animated: true)
        case .chat:
            print("Chat")
            self.navigationController?.pushViewController(self.chatViewController, animated: true)
        case .terapie:
            print("Terapie")
        }
    }
    
    
}
