//
//  AifaAPI.swift
//  Webservic
//
//  Created by giuseppe palumbo on 01/03/2017.
//  Copyright © 2017 giuseppe palumbo. All rights reserved.
//

import Foundation

class AifaAPI {
    
    static let domain = "https://www.agenziafarmaco.gov.it/services/search/select?"
    
    static let codiceFarmaco = "sm_field_chiave_confezione"
    static let dittaFarmaco = "sm_field_descrizione_ditta"
    static let descrizioneFarmaco = "sm_field_descrizione_confezione"
    static let nomeFarmaco = "sm_field_descrizione_farmaco"
    static let principioFarmaco = "sm_field_descrizione_atc"
    
    static var farmaco :Farmaco? = Farmaco()
    
    
    
//Restituisce l'url a cui chiedere i dati
    
    public static func aifaURL(codiceFarmaco: String) -> URL {
        
        var components = URLComponents(string: domain)
        
        var queryItems = [URLQueryItem]()
        
        // la key filtro filtra gli attributi del risultato della select
        
        let filtro = dittaFarmaco+","+descrizioneFarmaco+","+nomeFarmaco+","+principioFarmaco
        
        // bundle:confezione_farmaco+sm_field_descrizione_farmaco:rocefin
        let q = "bundle:confezione_farmaco+sm_field_aic:"
        
        let df = "sm_field_codice_farmaco"
        
        // "fl":fl,
        let baseParams = ["fl":filtro,"q":q+codiceFarmaco,"df": df,"wt":"json"]
        
        //Inseriamo attributi (coppie chiave valore) al vettore di URLQueryItem
        for (key,value) in baseParams {
            let item = URLQueryItem(name: key, value: value)
            queryItems.append(item)
        }
        
        components?.queryItems = queryItems
        
        return (components?.url!)!
    }
    
    //Restituisce un farmaco a partire dal codice a 9 cifre
    static func fetchJSON(codice: String) {
        
        let url = aifaURL(codiceFarmaco:codice)
        
        let request = URLRequest(url: url)
        
        let configuration = URLSessionConfiguration.default
        
        
        let session = URLSession(configuration: configuration)
        
        //NUOVO NUOVO NUOVO
        //RICHIESTA WEB SERVICE NUOVA
        let task = session.dataTask(with: request) {
            (data, response, error) in
            // check for any errors
            guard error == nil else {
                print("error calling GET")
                print(error!)
                return
            }
            // make sure we got data
            guard let responseData = data else {
                print("Error: did not receive data")
                return
            }
            // parse the result as JSON, since that's what the API provides
            if let dictionary = json_parseData(data: responseData) {
                if let response = dictionary["response"] as? [String:Any] {
                    print(response)
                    if let docs = response["docs"] as? NSArray{
                        for doc in docs{
                            let i = doc as!  NSDictionary
                            let descr = i["sm_field_descrizione_confezione"] as! NSArray
                            let nome = i["sm_field_descrizione_farmaco"] as! NSArray
                            let ditta = i["sm_field_descrizione_ditta"] as! NSArray
                            let principio = i["sm_field_descrizione_atc"] as! NSArray
                            
                            
                            //Salvo i risultati nella variabile farmaco dichiarata nelle prime righe della classe perchè non mi fa ritornare il farmaco
                            self.farmaco?.code = codice
                            self.farmaco?.descrizione = descr[0] as! String
                            self.farmaco?.nome = nome[0] as! String
                            self.farmaco?.ditta = ditta[0] as! String
                            self.farmaco?.principio = principio[0] as! String
                            self.farmaco?.isNew = true
                            print("\nCodice: \(self.farmaco?.code)\nDescrizione:\(self.farmaco?.descrizione)")
                            //print("Farmaco:\nNome: \(f.nome)\nDescrizione:\(f.descrizione)")
                        }
                        if self.farmaco == nil{
                            self.farmaco = Farmaco(code: codice, nome: "_", ditta: "", descrizione: "", principio: "")
                        }
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "FarmacoDownloaded"), object: nil)
                    }
                }
            }
        }
        task.resume()
    }
 
    static func result (codice: String) {
        fetchJSON(codice: codice)
        }
    
}


//Ritorna un dizionario generato a partire dal file JSON
func json_parseData(data: Data) -> NSDictionary? {
    do {
        let json = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers)
        //print("[JSON] OK!")
        //print(json)
        return (json as? NSDictionary)
    } catch _ {
        //print("[ERROR] An error has happened with parsing of json data")
        return nil
    }
}


