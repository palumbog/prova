//
//  AddDrugTableViewController.swift
//  HealthSolutionApp
//
//  Created by Alberto Capriolo on 05/03/2017.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit
import Firebase

class AddDrugTableViewController: UITableViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    
    
    
    @IBOutlet weak var sharedSwitch: UISwitch!
    //NUOVO
    @IBOutlet weak var expiringText: UITextField!
    @IBOutlet weak var barcodeText: UITextField!
    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var quantityText: UITextField!
    @IBOutlet weak var reminderSwitch: UISwitch!
    @IBOutlet weak var descriptionText: UITextField!
    @IBOutlet weak var drugmakerText: UITextField!
    @IBOutlet weak var startReminderText: UITextField!
    @IBOutlet weak var endReminderText: UITextField!
   
   
   @IBOutlet weak var tipoText: UITextField!

    @IBOutlet weak var section1_1: UITableViewCell!
    @IBOutlet weak var section2_1: UITableViewCell!
    @IBOutlet weak var section2_2: UITableViewCell!
    @IBOutlet weak var section2_3: UITableViewCell!
    @IBOutlet weak var section2_4: UITableViewCell!
    @IBOutlet weak var section3_1: UITableViewCell!
    @IBOutlet weak var section3_2: UITableViewCell!
    @IBOutlet weak var section4_1: UITableViewCell!
    
   
   
    @IBOutlet weak var saveBtn: UIBarButtonItem!
    @IBOutlet weak var scanBtn: UIButton!
    
    @IBOutlet var tableAddView: UITableView!
    
    let datePicker = UIDatePicker()
    
    var manager : DataManager?
    var onlineManager : FirebaseManager?
   
   
    var local_drug : Farmaco?
    
    var local_image : UIImage?
    var farmaco_locale : Drug?
    var drug : Drug?
   
    @IBOutlet weak var imageDrug: UIImageView!
    @IBOutlet weak var sectionImage: UITableViewCell!
    
    static var codice : String?
    
    var ref: DatabaseReference!
    
    @IBAction func scanClick(_ sender: UIButton) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "qrScan")
        self.present(controller, animated: true, completion: nil)
        
    }

    let drugType = ["compresse", "capsule", "supposte", "cps", "fiale", "bustine", "flacone", "cpr","bust", "sup","pillole","polvere","polveri","gel","sciroppo","fiala","fiale","gocce","collirio","colliri","sospensione"]
    
    @IBAction func OKPressed(_ sender: Any) {
        checkNSet()
    }

    @IBAction func takePicture(_ sender: UIButton) {
        var imagePicker = UIImagePickerController()
        switch sender.tag {
        case 0://Fotocamera
            imagePicker.sourceType = .camera
            break
        case 1://Album
            imagePicker.sourceType = .photoLibrary
            break
        default:
            return
        }
        imagePicker.delegate = self
        
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        local_image = info[UIImagePickerControllerOriginalImage] as! UIImage
        //imageStore.setImage(local_image!, forKey: barcodeText.text!)
        imageDrug.image = local_image
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
    var ok = false
   
    override func viewDidLoad() {
        super.viewDidLoad()
      
        //barcodeText.keyboardType = .numberPad
        //changeStateSection(false)
        //prova number pad
        saveBtn.isEnabled = false
        createNumericPad()
        //fine prova
        createDataPicker(fieldTxt: expiringText, campo: "expiring")
        changeStateSection(false)
        reminderSwitch.setOn(false, animated: true)
      
      if(ok){
         barcodeText.text = "012745028"
         nameText.text = "TACHIPIRINA"
         expiringText.text = "gg-mm-aaaa"
         quantityText.text = "0"
         sharedSwitch.isOn = false
         descriptionText.text = "Paracetamolo"
         drugmakerText.text = "AZIENDE CHIMICHE RIUNI..."
         tipoText.text = "COMPRESSE"
      }
      ok = true
      
        NotificationCenter.default.addObserver(self, selector: #selector(checkNSet(_:)), name: NSNotification.Name(rawValue: "BarcodeExtracted"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(checkFarmaco(_:)), name: NSNotification.Name(rawValue: "FarmacoDownloaded"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(insertCodeBox(_:)), name: NSNotification.Name(rawValue: "CodeBox") , object: nil)
        ref = Database.database().reference()
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var showRow5 = false
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row >= 6{
            return showRow5 ? UITableViewAutomaticDimension : 0
        }
        if indexPath.section == 3{
            if indexPath.row == 1{
                return 250
            }
        }
        return UITableViewAutomaticDimension
    }

    @IBAction func saveButtonClick(_ sender: UIBarButtonItem) {
        //operazioni di salvataggio
      if(checkCampi()){
         var drugBox : Drug
         if (local_drug?.isNew)!{
            print("Nuovo farmaco")
            drug = manager!.createDrug(code: (local_drug?.code)!, nameDrug: (local_drug?.nome)!, quantityDrug: (local_drug?.quantita)!, activePrincipeDrug: (local_drug?.principio)!, drugmakerDrug: (local_drug?.ditta)!,typeDrug: tipoText.text!)
            print("Drug salvata")
         }else{
            drug = (local_drug?.drug)!
         }
         var shared = false
         if(sharedSwitch.isOn){
            if let user = manager?.getUser(){
               onlineManager?.insertDrug(drug: drug!)
               onlineManager?.insertBox(drugCode: (drug?.codeDrug!)!, dateExpiring: datePicker.date as NSDate, quantityRemaining: Int(quantityText.text!)!, nickname: user.nickname!)
               onlineManager?.insertZonaFarmaci(zona: user.provincia!, drugCode: (drug?.codeDrug)!)
               shared = true
            }else{
               self.navigationController?.view.makeToast("Devi creare il profilo per condividere")
               manager?.addBoxToDrug(theDrug: drug!, dateExpiring: datePicker.date as NSDate, quantityRemaining: Int(quantityText.text!)!,shared: shared)
               self.navigationController?.view.makeToast("Salvato")
               navigationController?.popViewController(animated:true)
            }
         }else{
            manager?.addBoxToDrug(theDrug: drug!, dateExpiring: datePicker.date as NSDate, quantityRemaining: Int(quantityText.text!)!,shared: shared)
            self.navigationController?.view.makeToast("Salvato")
            navigationController?.popViewController(animated:true)
         }
      }
   }

    func changeStateSection(_ x: Bool){
        expiringText.isEnabled = x
        nameText.isEnabled = x
        quantityText.isEnabled = x
        drugmakerText.isEnabled = x
        descriptionText.isEnabled = x
        saveBtn.isEnabled = x
        tipoText.isEnabled = x
    }
    
    
    /*deinit {
        NotificationCenter.default.removeObserver(self)
    }*/
    
    @IBAction func changeColor(_ sender: UITextField) {
        sender.textColor = UIColor.black
    }
    
    @IBAction func switchChange(_ sender: UISwitch) {
        showRow5 = sender.isOn
        
        tableAddView.reloadData()
        
        createDataPicker(fieldTxt: startReminderText, campo: "reminder")
        createDataPicker(fieldTxt: endReminderText, campo: "reminder")
    }
    
    //Quando schiacci OK
    func checkNSet(){
        let codice = barcodeText.text
        if(codice != nil && codice != ""){
            check(codice: codice!)
        }
    }
    //Quando prendi il codice da barcode
    func checkNSet(_ notification: NSNotification){
        let codice = AddDrugTableViewController.codice
        if(codice != nil && codice != ""){
            check(codice: codice!)
        }
    }
   
   
   func insertCodeBox(_ notification: NSNotification){
      if let code = notification.userInfo?["code"] as? String{
         manager?.addBoxToDrug(theDrug: drug!, dateExpiring: datePicker.date as NSDate, quantityRemaining: Int(quantityText.text!)!,shared: true,sharedKey : code)
         self.navigationController?.view.makeToast("Salvato")
         
         navigationController?.popViewController(animated:true)
      }
      
   }
   
    func check(codice: String){
        var farmaco_locale : [Drug]
        
            // ricerca in locale
            farmaco_locale = (manager?.getAllDrugs(by: DataManager.Case.code.rawValue, info: codice))!
        
            if (farmaco_locale.count == 0) {
                AifaAPI.result(codice: codice)
            }else{
                //l ho trovato in locale quindi mi tengo quello locale
                local_drug = Farmaco(code: codice, nome: (farmaco_locale[0].nameDrug)!, ditta: (farmaco_locale[0].drugmakerDrug)!, descrizione: farmaco_locale[0].typeDrug!, principio: (farmaco_locale[0].activePrincipeDrug)!,quantita:Int16(0), isNew: false,drugReference: farmaco_locale[0])
                setLabels()
        }
        
    }
    
    func checkFarmaco(_ notification: NSNotification){
        let farmaco = AifaAPI.farmaco
        
        if (farmaco?.nome == "_"){
            //non presente nè in locale  nè online quindi creo un nuovo farmaco in locale
            local_drug = Farmaco(code: farmaco!.code, nome: "", ditta: "", descrizione: "", principio: "",quantita: Int16(0), isNew: true, drugReference: nil)
        }else{
            //l ho trovato online ma non in locale
            local_drug = farmaco
            
            
            // funzione estrapolazione quantità da assegnare a questo
            /*
             if let quantita = quantityParser(farmaco!.descrizione){
             local_drug!.quantita = Int16(quantita)!
             }else {
             local_drug!.quantita = 0
             }*/
            local_drug!.quantita = 0
        }
        setLabels()
    }
    
    func setLabels(){
      
      DispatchQueue.main.async(execute: {
         
         self.changeStateSection(true)
         //print("cambio stato")
         self.changeColor(self.barcodeText)
         self.changeColor(self.nameText)
         self.changeColor(self.quantityText)
         self.changeColor(self.descriptionText)
         self.changeColor(self.drugmakerText)
         self.changeColor(self.tipoText)
         
         self.barcodeText.text = self.local_drug!.code
         self.nameText.text = self.local_drug!.nome
         self.quantityText.text = "\(self.local_drug!.quantita)"
         self.descriptionText.text = self.local_drug!.principio
         self.drugmakerText.text = self.local_drug!.ditta
         self.tipoText.text = self.getTipo()
      })
      
    }
   
   func getTipo() -> String{
      let descr = local_drug?.descrizione.lowercased()
      if(descr != ""){
         for s in drugType{
            if (descr?.contains(s))!{
               return s.uppercased()
            }
         }
      }
      return ""
   }
    
    func quantityParser(_ descrizione: String) -> String?{
        //TODO fare qusti if all'interno di un ciclo for che scorre l'array chiamato drugType
        var toReturn: String = ""
        for str in drugType {
            if descrizione.lowercased().contains(str) {
                var searchRange = descrizione.startIndex..<descrizione.endIndex
                var indexes: [String.Index] = []
                while let range = descrizione.range(of: str, options: .caseInsensitive, range: searchRange) {
                    searchRange = range.upperBound..<searchRange.upperBound
                    indexes.append(range.lowerBound)
                    let idx = descrizione.index((range.lowerBound), offsetBy: -3)
                    let r = idx..<(range.lowerBound)
                    toReturn = descrizione.substring(with: r).trimmingCharacters(in: CharacterSet.whitespaces)
                }
                return toReturn
            }
        }
        return nil
    }
    
    func createNumericPad(){
        let toolbar1 = UIToolbar()
        
        toolbar1.sizeToFit()
      let doneButton1 = //UIBarButtonItem(title: "Fatto", barButtonSystemItem: .done, target: nil, action: #selector(donePressedPad))
      
      UIBarButtonItem(title: "Fatto", style: .done, target: nil, action: #selector(donePressedPad))
      
        toolbar1.setItems([doneButton1], animated: false)
        
        barcodeText.inputAccessoryView = toolbar1
        quantityText.inputAccessoryView = toolbar1
        barcodeText.keyboardType = .numberPad
        
    }
    
    func createDataPicker(fieldTxt: UITextField, campo: String){
        
        if campo == "expiring" {
            datePicker.datePickerMode = .date
        }else{
            datePicker.datePickerMode = .dateAndTime
        }
        
        
        let toolbar = UIToolbar()
        
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Fatto", style: .done, target: nil, action: #selector(donePressed))
        let cancelButton = UIBarButtonItem(title: "Cancella", style: .plain, target: nil, action: #selector(cancelPressed))
        
        toolbar.setItems([cancelButton,doneButton], animated: false)
        fieldTxt.inputAccessoryView = toolbar
        fieldTxt.inputView = datePicker
        
        
        
        
        
        
        datePicker.addTarget(self, action: #selector(AddDrugTableViewController.datePickerDidSelectNewDate(_:)), for: .valueChanged)
        
    }
    
    func datePickerDidSelectNewDate(_ sender: UIDatePicker) {
        let selectedDate = sender.date
        let delegate = UIApplication.shared.delegate as? AppDelegate
        delegate?.scheduleNotification(at: selectedDate)
        
    }
   
   func checkCampi() -> Bool{
      let expiring = expiringText.text
      let quantita = quantityText.text
      if(expiring == nil || expiring == "" || expiring == "gg-mm-aaaa"){
         self.navigationController?.view.makeToast("Inserisci data di scadenza")
         return false
      }
      if(quantita == nil || quantita == "0"){
         self.navigationController?.view.makeToast("Inserisci quantità")
         return false
      }
      return true
   }
   
    
    func cancelPressed(){
        self.view.endEditing(true)
    }
    
    func donePressedPad(){
        //richiamare funzione di ricerca interna e online
        self.changeColor(barcodeText)
        self.view.endEditing(true)
        
    }
    func donePressed(){
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .short
        dateFormatter.timeStyle = .none
        
        expiringText.text = dateFormatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }
    
    func setBorder(row: UITableViewCell){
        row.layer.borderWidth = 1
        row.layer.borderColor = UIColor.lightGray.cgColor
    }
    
    // MARK: - Table view data source
    /*
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 4
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 0
    }*/

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    /*
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        print("SEGUE IDENTIFIER : \(segue.identifier!)")
        switch segue.identifier! {
        case "saveNewDrug":
            var drugBox : Drug
            if (local_drug?.isNew)!{
                print("******ENTRO******\n\n\n\n")
                
                //NUOVO
                if (imageDrug.image != nil) {
                    drugBox = DrugPersistenceData.newItem(code: local_drug!.code, nameDrug: nameText.text!, quantityDrug: Int16(quantityText.text!)!, activePrincipeDrug: descriptionText.text!, drugmakerDrug: drugmakerText.text!,imageDrug: imageDrug.image!)
                    print(imageDrug.image)
                }
                //FINE NUOVO
                else {
                drugBox = DrugPersistenceData.newItem(code: local_drug!.code, nameDrug: nameText.text!, quantityDrug: Int16(quantityText.text!)!, activePrincipeDrug: descriptionText.text!, drugmakerDrug: drugmakerText.text!)
                }
                
                DrugPersistenceData.saveContext()
                print("Drug salvata")
            }else{
                drugBox = (local_drug?.drug)!
            }
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd/MM/yyyy"
            print("EXPIRING TEXT : \(expiringText.text!)")
            let date = dateFormatter.date(from: expiringText.text!)
            print("Data convertita \(date) \(drugBox) \(quantityText.text) ")
            BoxPersistenceData.newItem(dateExpiring: date!, drug: drugBox, quanitityRemaining: Int16(quantityText.text!)!)
            BoxPersistenceData.saveContext()
            /*if let currentindex = drugsTable.indexPathForSelectedRow?.row{
             
             let itemCurrent = pBox[currentindex]
             let dstView = segue.destination as! DetailsViewController
             /*dstView.currentItem = itemCurrent
             dstView.imageStore = imageStore*/
             
             }*/
        
        case "cancelNewDrug": break
        //print("contentuto")
        case "unwindToViewController": break
        default:
            preconditionFailure("Segue non valido.")
        }
    }
 */

}
