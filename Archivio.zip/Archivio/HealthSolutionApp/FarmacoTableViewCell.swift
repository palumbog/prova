//
//  FarmacoTableViewCell.swift
//  DrugBox
//
//  Created by gpalumbo on 27/06/17.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit

class FarmacoTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var quantityLabel: UILabel!
    
    @IBOutlet weak var boxesLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
