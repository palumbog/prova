//
//  DrugsTableViewCell.swift
//  FinalApp
//
//  Created by Alberto Capriolo on 01/03/2017.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit

class DrugsTableViewCell: UITableViewCell {

    @IBOutlet weak var imageDrug: UIImageView!
    @IBOutlet weak var nameDrug: UILabel!
    @IBOutlet weak var dateExiringDrug: UILabel!
    @IBOutlet weak var quantityDrug: UILabel!
        
    @IBOutlet weak var stepper: UIStepper!

    var oldValue : Double = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        //stepper.stepValue = 1
        oldValue = stepper.value
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func pressed(_ sender: Any) {
        
        let myString2 = quantityDrug.text!
        let myInt2 = (myString2 as NSString).integerValue
        
        if oldValue < stepper.value{
            

           quantityDrug.text =  "\(myInt2 + 1)"
        }else{
            quantityDrug.text = "\(myInt2 - 1)"
        }
        oldValue = stepper.value
    }

}
