//
//  DrugPersistenData.swift
//  HealthSolutionApp
//
//  Created by Alberto Capriolo on 02/03/2017.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import Foundation
import CoreData
import UIKit
class DrugPersistenceData {
    static let name =  "Drug"
   /*
    static func getContext() -> NSManagedObjectContext{
        //let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        //return appDelegate.persistentContainer.viewContext
        
        
    }
 */
    
    static func newEmptyItem (code: String) -> Drug {
        let context = getContext()
        
        let pDrug = NSEntityDescription.insertNewObject(forEntityName: name, into: context) as! Drug
        
        pDrug.codeDrug = code
        //pDrug.categoryDrug = "newCategory"
        
        return pDrug
    }
    
    static func createDrug (code: String,nameDrug: String,quantityDrug: Int16,activePrincipeDrug: String,drugmakerDrug: String) -> Drug {
        
        
        let pDrug = Drug()
        
        
        pDrug.codeDrug = code
        pDrug.nameDrug = nameDrug
        pDrug.activePrincipeDrug = activePrincipeDrug
        pDrug.drugmakerDrug = drugmakerDrug
        pDrug.quantityDrug = quantityDrug
        //pDrug.categoryDrug = "newCategory"
        
        return pDrug
    }
    
    //NUOVO
    
    static func newItem (code: String,nameDrug: String,quantityDrug: Int16,activePrincipeDrug: String,drugmakerDrug: String,imageDrug: UIImage) -> Drug {
        let context = getContext()
        
        let pDrug = NSEntityDescription.insertNewObject(forEntityName: name, into: context) as! Drug
        
        
        pDrug.codeDrug = code
        pDrug.nameDrug = nameDrug
        pDrug.activePrincipeDrug = activePrincipeDrug
        pDrug.drugmakerDrug = drugmakerDrug
        pDrug.quantityDrug = quantityDrug
        pDrug.imageKey = UIImagePNGRepresentation(imageDrug) as NSData?
        //pDrug.categoryDrug = "newCategory"
        
        return pDrug
    }
    
    //FINE NUOVO
    
    static func newItem (code: String,nameDrug: String,quantityDrug: Int16,activePrincipeDrug: String,drugmakerDrug: String) -> Drug {
        let context = getContext()
        
        let pDrug = NSEntityDescription.insertNewObject(forEntityName: name, into: context) as! Drug
        
        
        pDrug.codeDrug = code
        pDrug.nameDrug = nameDrug
        pDrug.activePrincipeDrug = activePrincipeDrug
        pDrug.drugmakerDrug = drugmakerDrug
        pDrug.quantityDrug = quantityDrug
        //pDrug.categoryDrug = "newCategory"
        
        return pDrug
    }
    
    static func searchDrug(code :String) -> Drug? {
        var drug: Drug?
        
        let context = getContext()
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Drug")
        request.predicate = NSPredicate(format: "codeDrug = %@", code)
        request.returnsObjectsAsFaults = false
        
        do {
            //let result: NSArray = try request.executeFetchRequest(request)
            //let result: NSArray = try context.execute(request)
            
            let result = try context.fetch(request)
            
            switch result.count {
            case 0:
                print("The drug: \(code) not exists in CoreData!")
                
                return nil
                
            case 1:
                print("The drug: \(code) is in coreData")
                
                drug = result[0] as? Drug
                return drug!
            default:
                if (result.count>1) {
                    print("More element found.")
                }
                return nil
            }
            
        } catch let error {
            print("Error:  \(error.localizedDescription) ")
        }
        
        return nil
    }
    
    static func fetchData() -> [Drug]{
        
        var items = [Drug]()
        
        let context = getContext()
        
        let fetchRequest =  NSFetchRequest<Drug>(entityName: name)
        
        do{
            try items = context.fetch(fetchRequest)
        }catch let error as NSError{
            print("Error during fetching \(error.code) ")
        }
        return items
    }
    
    //Fetcha solo i farmaci con numero di scatoli > 0
    //E' importante la chiocciola nel predicato boxe.@count
    static func fetchDataDrug() -> [Drug]{
        var items = [Drug]()
        
        
        let context = getContext()
        
        let fetchRequest =  NSFetchRequest<Drug>(entityName: name)
        
        fetchRequest.predicate = NSPredicate(format: "boxes.@count > 0")
        
        
        do{
            try items = context.fetch(fetchRequest)
        }catch let error as NSError{
            print("Error during fetching \(error.code) ")
        }
        return items
    }
    
    static func saveContext(){
        let context = getContext()
        
        do{
            try context.save()
        }catch let error as NSError{
            print("Error during saving \(error.code) ")
        }
        
    }
    
    static func deleteContext(item: Drug){
        let context = getContext()
        
        do{
            try context.delete(item)
        }catch let error as NSError{
            print("Error during deleting \(error.code) ")
        }
        
    }
}
