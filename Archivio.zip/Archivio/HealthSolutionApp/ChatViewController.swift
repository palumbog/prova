//
//  ChatViewController.swift
//  DrugBox
//
//  Created by Admin on 27/07/17.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit

class ChatViewController: UITableViewController {

    let onlineManager = MenuController.onlineController
    let manager = MenuController.manager
    
    @IBOutlet var chatTable: UITableView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        navigationItem.title = "Chat"
        
        setupNavItem()
        NotificationCenter.default.addObserver(self, selector: #selector(messaggiScaricati(_:)), name: NSNotification.Name(rawValue: "MessagesDownloaded"), object: nil)
        guard let user = manager.getUser() else{
            self.navigationController?.view.makeToast("Crea un profilo")
            return
        }
        chatTable.tableHeaderView = nil
        chatTable.tableFooterView = UIView()
        onlineManager.getUserMessages(user: user.nickname!)
        
    }
    private func setupNavItem(){
        let myView = UIView(frame: CGRect(x: 0, y: 0, width: 150 , height: 50) )
        myView.backgroundColor = UIColor.clear
        myView.clearsContextBeforeDrawing = true
        let tv = UITextView(frame: CGRect(x: 30, y: 5, width: 70, height: 70 ))
        tv.text = "Chat"
        tv.font = UIFont.systemFont(ofSize: 20)
        tv.allowsEditingTextAttributes = false
        tv.backgroundColor = UIColor.clear
        let imageView = UIImageView(frame: CGRect(x: 70, y: -8, width: 70, height: 70))
        myView.addSubview(tv)
        myView.addSubview(imageView)
    
                //imageView.backgroundColor = UIColor.black
        imageView.contentMode = .scaleAspectFit
        let image = #imageLiteral(resourceName: "Chat Image")
        imageView.image = image
        navigationItem.titleView = myView
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    func messaggiScaricati(_ notification: NSNotification){
        DispatchQueue.main.async{
            self.chatTable.reloadData()
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        onlineManager.setIsFirstTime(isFirstTime: true)
        onlineManager.setWasFirstTime(isFirstTime: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        let count = onlineManager.userMessages.count
        return count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = chatTable.dequeueReusableCell(withIdentifier: "chatCell", for: indexPath) as! ChatTableViewCell
        let messages = onlineManager.userMessages
        let message = messages[indexPath.row]
       
        cell.nicknameLabel.text = message.getChatPartner()
        cell.messageLabel.text = message.message
        
        
        
        cell.timestampLabel.text = getTimestamp(timestamp: TimeInterval(message.timestamp!))
        // Configure the cell...
        return cell
    }
    
    
 
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return 80.0;//Choose your custom row height
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let message = onlineManager.userMessages[indexPath.row]
        let view = ChatLogController(collectionViewLayout: UICollectionViewFlowLayout())
        view.user = message.getChatPartner()
        
        view.onlineManager = onlineManager
        view.manager = manager
        navigationController?.pushViewController(view, animated: true)
    }
    
    func dayDifference(from interval : TimeInterval) -> String
    {
        let calendar = NSCalendar.current
        
        let date = Date(timeIntervalSince1970: interval)
        if calendar.isDateInYesterday(date) { return "Yesterday" }
        else if calendar.isDateInToday(date) { return "Today" }
        else if calendar.isDateInTomorrow(date) { return "Tomorrow" }
        else {
            let startOfNow = calendar.startOfDay(for: Date())
            let startOfTimeStamp = calendar.startOfDay(for: date)
            let components = calendar.dateComponents([.day], from: startOfNow, to: startOfTimeStamp)
            let day = components.day!
            if day < 1 { return "\(abs(day)) days ago" }
            else { return "In \(day) days" }
        }
    }
    func getTimestamp(timestamp: TimeInterval) -> String{
        let date = NSDate(timeIntervalSince1970: TimeInterval(timestamp))
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        dateFormatter.locale = Locale.init(identifier: "it_IT")
        let dateObj = dateFormatter.string(from: date as Date)
        
        let result = dayDifference(from: timestamp)
        switch result {
            case "Yesterday":
            return "Ieri " + dateObj
            case "Today":
            return "Oggi " + dateObj
        default:
            dateFormatter.dateFormat = "dd/MM/yyyy HH:mm"
            return dateFormatter.string(from: date as Date)
        }
    }
 

   

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
