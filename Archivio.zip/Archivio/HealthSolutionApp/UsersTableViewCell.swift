//
//  UsersTableViewCell.swift
//  DrugBox
//
//  Created by gpalumbo on 05/07/17.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit

class UsersTableViewCell: UITableViewCell {

    @IBOutlet weak var nicknameLabel: UILabel!
    
    @IBOutlet weak var scatoliLabel: UILabel!
    
    @IBAction func chatPressed(_ sender: Any) {
        print("Apri chat view")
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
