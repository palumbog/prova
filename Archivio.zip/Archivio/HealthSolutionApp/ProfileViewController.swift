//
//  ProfileViewController.swift
//  DrugBox
//
//  Created by gpalumbo on 29/06/17.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit
import Toast_Swift

class ProfileViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    var province = [String]()
    var manager = MenuController.manager
    var onlineManager = MenuController.onlineController
    @IBOutlet weak var nicknameTextField: UITextField!
    @IBOutlet weak var provinciaTextField: UITextField!
    let provinciaPicker = UIPickerView()
    
    var user : User?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavItem()
        provinciaPicker.delegate = self
        provinciaPicker.dataSource = self
        
        NotificationCenter.default.addObserver(self, selector: #selector(notifyChangeNickname(_:)), name: NSNotification.Name(rawValue: "UserFound") , object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(insertUser(_:)), name: NSNotification.Name(rawValue: "UserNotFound") , object: nil)
        // Do any additional setup after loading the view.
        provinciaTextField.inputView = provinciaPicker
        
        
    }
    
    func notifyChangeNickname(_ notification :NSNotification){
        self.navigationController?.view.makeToast("Nickname già esistente")
    }
    func insertUser(_ notification : NSNotification){
        if(manager.createUser(nickname: nicknameTextField.text!, provincia: provinciaTextField.text!)){
            onlineManager.insertUser(nickname: nicknameTextField.text!, provincia: provinciaTextField.text!)
            self.navigationController?.view.makeToast("Profilo salvato")
            
        }else{
            self.navigationController?.view.makeToast("Profilo non salvato")
        }
    }
    
    func checkUser(){
        if let user = manager.getUser(){
            nicknameTextField.text = user.nickname
            provinciaTextField.text = user.provincia
        }
    }
    
    @IBAction func saveButtonPressed(_ sender: Any) {
        view.endEditing(true)
        if(checkCampi()){
            onlineManager.searchUser(nickname: nicknameTextField.text!)
        }
    }
    
    func checkCampi() -> Bool {
        let nick = nicknameTextField.text
        let prov = provinciaTextField.text
        var okNick : Bool = false
        var okProv : Bool = false
        
        if(nick != nil && nick != "" ){
            okNick = true
        }
        if(prov != nil && prov != ""){
            okProv = true
        }
        if(okNick && okProv){
            return true
        }else if (!okNick){
            self.navigationController?.view.makeToast("Inserisci nickname")
        }else{
            self.navigationController?.view.makeToast("Inserisci provincia")
        }
        return false
    }
    
    override func  viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        province = getArrayFromJson()!
        checkUser()
    }
    
    func getArrayFromJson() -> [String]? {
        if let path = Bundle.main.path(forResource: "province", ofType: "json"){
            do {
                let jsonData = try NSData(contentsOfFile: path, options: NSData.ReadingOptions.mappedIfSafe)
                do {
                    let jsonResult: NSDictionary = try JSONSerialization.jsonObject(with: jsonData as Data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    if let province : [String] = jsonResult["province"] as? [String] {
                        return province
                    }
                } catch {}
            } catch {}
        }
        return nil
    }
    
    func sorterDrugsByNameDisc(d1: String,d2 : String) -> Bool{
        return d1 < d2
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView,
                    numberOfRowsInComponent component: Int) -> Int {
        return province.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return province[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        provinciaTextField.text = province[row]
        self.view.endEditing(true)
    }
    
    
    private func setupNavItem(){
        let myView = UIView(frame: CGRect(x: 0, y: 0, width: 150 , height: 50) )
        myView.backgroundColor = UIColor.clear
        myView.clearsContextBeforeDrawing = true
        let tv = UITextView(frame: CGRect(x: 30, y: 5, width: 70, height: 70 ))
        tv.text = "Profilo"
        tv.font = UIFont.systemFont(ofSize: 20)
        tv.allowsEditingTextAttributes = false
        tv.backgroundColor = UIColor.clear
        let imageView = UIImageView(frame: CGRect(x: 90, y: -8, width: 60, height: 60))
        myView.addSubview(tv)
        myView.addSubview(imageView)
        
        //imageView.backgroundColor = UIColor.black
        imageView.contentMode = .scaleAspectFit
        let image = #imageLiteral(resourceName: "Profilo1 ")
        imageView.image = image
        navigationItem.titleView = myView
    }

    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
