//
//  TableViewController.swift
//  DrugBox
//
//  Created by giuseppe palumbo on 28/08/2017.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit

enum LeftMenu: Int {
    case farmaci = 0
    case terapie
    case farmaciCondivisi
    case online
    case chat
    case profilo
}

class MenuController: UITableViewController {

    
    static let manager = DataManager.sharedInstance
    static let onlineController = FirebaseManager.sharedInstance

    var user = MenuController.manager.getUser()
    
    @IBOutlet var menuTable: UITableView!
    var mieiFarmaciViewController: UIViewController!
    var mieiFarmaciOnlineController: UIViewController!
    var farmaciOnlineViewController: UIViewController!
    var profiloViewController: UIViewController!
    var sharedViewController: UIViewController!
    var chatViewController: UIViewController!
    var mySharedViewController : UIViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "DrugBox"
        
        //navigationController?.navigationBar.barTintColor = UIColor(red: 10/255, green: 100/255, blue: 1, alpha: 1)
        //self.view.backgroundColor = UIColor(red: 10/255, green: 100/255, blue: 1, alpha: 1)
        menuTable.sectionHeaderHeight = 50
        menuTable.tableFooterView = UIView()
        navigationController?.navigationBar.backgroundColor = ChatCell.blueColor
        //self.view.backgroundColor = UIColor(red: 50/255, green: 100/255, blue: 1, alpha: 1)
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        
        //MenuController.manager.createUser(nickname: "chiara72", provincia: "Agrigento")
        
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        setupViews()
        self.tableView.separatorColor = UIColor.clear
    }
    override func viewWillAppear(_ animated: Bool) {
        user = MenuController.manager.getUser()
        menuTable.reloadData()
    }
    
    private func setupViews() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let mieiFarmaciViewController = storyboard.instantiateViewController(withIdentifier: "DrugList") as! DrugsViewController
        self.mieiFarmaciViewController = mieiFarmaciViewController
        
        let profiloViewController = storyboard.instantiateViewController(withIdentifier: "ProfiloViewController") as! ProfileViewController
        self.profiloViewController = profiloViewController
        
        let sharedViewController = storyboard.instantiateViewController(withIdentifier: "SharedView") as! SharedViewController
        self.sharedViewController = sharedViewController
        
        let chatViewController = storyboard.instantiateViewController(withIdentifier: "ChatView") as! ChatViewController
        self.chatViewController = chatViewController
        
        let mySharedViewController = storyboard.instantiateViewController(withIdentifier: "MySharedView") as! MySharedTableController
        self.mySharedViewController = mySharedViewController
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let menu = LeftMenu(rawValue: indexPath.row) {
            self.changeViewController(menu)
        }
    }
    
    func changeViewController(_ menu : LeftMenu){
        switch menu {
        case .farmaci:
            print("Miei Farmaci")
            launchView(self.mieiFarmaciViewController)
        case .farmaciCondivisi:
            print("Miei Farmaci Condivisi")
            if checkUser(){
                launchView(self.mySharedViewController)
            }else{
                toast("Crea il profilo nel menù Profilo!")
            }
        //self.slideMenuController()?.changeMainViewController(self.swiftViewController, close: true)
        case .online:
            print("Farmaci Online")
            if checkUser(){
                launchView(self.sharedViewController)
            }else{
                toast("Crea il profilo nel menù Profilo!")
            }
            
            
        case .profilo:
            print("Profilo")
            launchView(self.profiloViewController)
        case .chat:
            print("Chat")
            if checkUser(){
                launchView(self.chatViewController)
            }else{
                
                toast("Crea il profilo nel menù Profilo!")
            }
        case .terapie:
            print("Terapie")
            toast("In fase di sviluppo...")
        }
    }
    
    private func toast(_ text : String){
        self.navigationController?.view.makeToast(text)
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section
        {
        case 0:
            if self.user == nil{
                return "Ciao!"
            }else{
                return "Ciao \((user?.nickname)!)!"
            }
            
        default:
            return ""
        }
    }
    
    private func checkUser() -> Bool {
        if self.user != nil {
            return true
        }
        return false
    }
    private func launchView(_ view : UIViewController) {
        self.navigationController?.pushViewController(view, animated: true)
    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        if let headerView = view as? UITableViewHeaderFooterView {
            headerView.textLabel?.textAlignment = .center
        }
    }
    
    

}
