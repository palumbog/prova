//
//  DetailsViewController.swift
//  HealthSolutionApp
//
//  Created by Alberto Capriolo on 02/03/2017.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit

/*class AddIncomeVC: UIViewController {
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var views: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        scrollView.contentSize = views.frame.size
        scrollView.addSubview(views)
        
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        views.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height)
        
    }
    
}*/


class DetailsViewController: UIViewController {

    /*@IBOutlet var scrollView: UIScrollView!
    @IBOutlet var views: UIView!*/
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.rightBarButtonItem = self.editButtonItem
        /*scrollView.contentSize = views.frame.size
        scrollView.addSubview(views)*/
        // Do any additional setup after loading the view.
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        /*views.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height)*/
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        switch segue.identifier {
        case "editDrug"?:
            print("prova edit")
        
        default:
            preconditionFailure("Segue non valido.")
        }

    }
    

}
