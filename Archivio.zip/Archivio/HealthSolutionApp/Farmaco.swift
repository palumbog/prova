//
//  Farmaco.swift
//  Webservic
//
//  Created by giuseppe palumbo on 01/03/2017.
//  Copyright © 2017 giuseppe palumbo. All rights reserved.
//

import Foundation

class Farmaco: NSObject {
    var code,nome,ditta,descrizione,principio : String
    var isNew: Bool?
    var drug : Drug?
    var quantita: Int16
     //let drug : Drug = self.createDrug( quantityDrug: (dic["quantita"])! as! Int16)
    
    init(code:String, nome: String,ditta : String,principio: String,quantita : Int16) {
        self.code = code
        self.nome = nome
        self.ditta = ditta
        self.principio = principio
        self.quantita = quantita
        self.descrizione = ""
    }
    
    init(code:String, nome: String,ditta : String,principio: String,quantita : Int16,descrizione : String) {
        self.code = code
        self.nome = nome
        self.ditta = ditta
        self.principio = principio
        self.quantita = quantita
        self.descrizione = descrizione
    }
    
    init(code:String, nome: String,ditta : String,descrizione: String,principio: String) {
        self.code = code
        self.nome = nome
        self.ditta = ditta
        self.descrizione = descrizione
        self.principio = principio
        self.isNew = true
        self.quantita = 0
    }
    override init() {
        self.code = ""
        self.nome = ""
        self.ditta = ""
        self.descrizione = ""
        self.principio = ""
        self.isNew = true
        self.quantita = 0
    }
    init(code:String, nome: String,ditta : String,descrizione: String,principio: String,quantita: Int16, isNew: Bool, drugReference: Drug?) {
        self.code = code
        self.nome = nome
        self.ditta = ditta
        self.descrizione = descrizione
        self.principio = principio
        self.quantita = quantita
        self.isNew = isNew
        if !isNew {
            self.drug = drugReference!
        }
    }
}
