//
//  DrugsViewController.swift
//  HealthSolutionApp
//
//  Created by Alberto Capriolo on 01/03/2017.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit
import Firebase

class DrugsViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {
    
    
    @IBOutlet weak var plusButton: UIBarButtonItem!
    
    
    @IBOutlet weak var viewImage: UIView!
    
    
    var noDrugs = false
    @IBOutlet weak var drugsTable: UITableView!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var imageView: UIImageView!
    
    @IBAction func changeValueSegmentControl(_ sender: UISegmentedControl) {
        
        checkSegment()
        
    }
    
    func checkSegment(){
        switch segmentControl.selectedSegmentIndex {
        case 0:
            pBox = MenuController.manager.getAllBoxes(by: DataManager.Case.nonScaduti.rawValue, orderedBy: DataManager.BoxOrder.dataAsc.rawValue)
            filter1YearBoxes()
            drugsTable.reloadData()
        case 1:
            pBox = MenuController.manager.getAllBoxes(by: DataManager.Case.scaduti.rawValue, orderedBy: DataManager.BoxOrder.dataDisc.rawValue)
            drugsTable.reloadData()
        case 2:
            pDrug = MenuController.manager.getDrugsWithNotExpiredBox()
            drugsTable.reloadData()
        case 3:
            pBox = MenuController.manager.getAllBoxes(orderedBy: DataManager.BoxOrder.dataDisc.rawValue)
            drugsTable.reloadData()
        default:
            break
        }
    }
    
    var pDrug : [Drug]?
    var pBox : [Box]?
    
    
    
    
    override func viewDidLoad() {
        segmentControl.clipsToBounds = true
        super.viewDidLoad()
        
        
        
        
        
        
        
        //DrugsViewController.onlineController.observeDrugsPlace(zona: "")
        pBox = MenuController.manager.getAllBoxes(by: DataManager.Case.nonScaduti.rawValue, orderedBy: DataManager.BoxOrder.dataAsc.rawValue)
        //Fetcho solo i farmaci con num di scatoli > 0
        
        drugsTable.delegate = self
        drugsTable.dataSource = self
        drugsTable.reloadData()
        
        drugsTable.tableFooterView = UIView()
        
        //self.setNavigationBarItem()
        navigationItem.setRightBarButton(plusButton, animated: false)
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        //self.navigationItem.leftBarButtonItem = self.editButtonItem
    }
    
    override func  viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        checkSegment()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Table view data source
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        var count = 0
        var segment = segmentControl.selectedSegmentIndex
        
        switch segment {
        case 2 :
            count = (pDrug?.count)!
        default :
            count = (pBox?.count)!
        }
        if count == 0 {
            noDrugs = true
            return 1
        }
        noDrugs = false
        return count
    }
    
    
    private func filter1YearBoxes(){
        var i = 0
        for box in pBox!{
            if !DataManager.sharedInstance.boxExpiringYear(box: box){
                pBox?.remove(at: i)
                i -= 1
            }
            i += 1
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell :  DrugsTableViewCell
        var cell2 : TextCell
        var cell3 : FarmacoTableViewCell
        var segment = segmentControl.selectedSegmentIndex
        
        if (segment == 0 || segment == 1 || segment == 3){
            if noDrugs{
                cell2 = self.drugsTable.dequeueReusableCell(withIdentifier: "textCell", for: indexPath) as! TextCell
                
                
                if segment == 1{
                    cell2.testoLabel.text = "Nessun farmaco scaduto"
                }else{
                    if pBox!.capacity == 0 && DataManager.sharedInstance.getAllBoxes().capacity > 0{
                        cell2.testoLabel.text = "Nessun farmaco in scadenza"
                    }
                    else{
                    cell2.testoLabel.text = "Nessun farmaco...Aggiungine uno!"
                    }
                }
                
                return cell2
            }
            
        let box = pBox?[indexPath.row]
            
        cell = self.drugsTable.dequeueReusableCell(withIdentifier: "idCell", for: indexPath) as! DrugsTableViewCell
            
        cell.nameDrug.text = box?.drug!.nameDrug
        cell.quantityDrug.text = "\((box?.quanitityRemaining)!) "
            
        let calendar = Calendar.current
        let date = (box?.dateExpiring!)!
            
        let year = calendar.component(.year, from: date as Date)
        let month = calendar.component(.month, from: date as Date)
        let day = calendar.component(.day, from: date as Date)
            
            
        cell.dateExiringDrug.text = "\(day)-\(month)-\(year)"
        
            
            
        if(MenuController.manager.boxScaduto(box: box!)){
            cell.dateExiringDrug.textColor = UIColor.red
        }
        else if DataManager.sharedInstance.boxExpiringYear(box: box!){
            cell.dateExiringDrug.textColor = UIColor.orange
        }
        else{
            cell.dateExiringDrug.textColor = UIColor.green
        }
 
        return cell
            
        }else if(segment == 2){
            print("Ho selezionato quantità")
            
            if noDrugs{
                cell2 = self.drugsTable.dequeueReusableCell(withIdentifier: "textCell", for: indexPath) as! TextCell
                
                
                
                cell2.testoLabel.text = "Nessun farmaco...Aggiungine uno!"
                
                
                return cell2
            }

            cell3 = self.drugsTable.dequeueReusableCell(withIdentifier: "idCellQuantity", for: indexPath) as! FarmacoTableViewCell
            
            let drug = pDrug?[indexPath.row]
            
            cell3.nameLabel.text = drug?.nameDrug
            var quantity : Int16
            quantity = MenuController.manager.getTotalQuantityDrug(drug: drug!)
            
            cell3.boxesLabel.text = "\((pDrug?[indexPath.row].boxes?.count)!)"
            
            print("Quantità di tutte le scatole: \(quantity)")
            
            cell3.quantityLabel.text = "\(quantity) "
            return cell3
            }
        //Non ci arriva mai
        return UITableViewCell()
    }
    
   
    
    
    // Override to support editing the table view.
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            if segmentControl.selectedSegmentIndex != 2{
                // Delete the row from the data source
                //Cancellare prima della cancellazione grafica
                var drug : Drug
                drug = (pBox?[indexPath.row].drug)!
                MenuController.manager.deleteContext(item: (pBox?[indexPath.row])!)
                pBox!.remove(at: indexPath.row)
                MenuController.manager.saveContext()
                drugsTable.deleteRows(at: [indexPath], with: .fade)
                
            }
            
            
        }
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if noDrugs{
            if segmentControl.selectedSegmentIndex != 1{
                UIApplication.shared.sendAction(plusButton.action!, to: plusButton.target, from: nil, for: nil)
            }
            
            //plusButton.target
        }
    }
    
    
    
    
    
    // MARK: - Navigation
    
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        //print("SEGUE IDENTIFIER : \(segue.identifier!)")
        
        switch segue.identifier! {
        case "showDrugShow":
            if let currentindex = drugsTable.indexPathForSelectedRow?.row{
                let itemCurrent = pBox?[currentindex]
                let dstView = segue.destination as! EditDrugTableViewController
                dstView.box = itemCurrent
                dstView.onlineManager = MenuController.onlineController
                dstView.manager = MenuController.manager
            }
        case "helpSegue":
            break
        case "addDrugShow":
            let dstView = segue.destination as! AddDrugTableViewController
            dstView.manager = MenuController.manager
            dstView.onlineManager = MenuController.onlineController
        /*case "showProfile":
            let dstView = segue.destination as!  ProfileViewController
            dstView.manager = DrugsViewController.manager
            dstView.onlineManager = DrugsViewController.onlineController
            break
        */
        default:
            preconditionFailure("Segue non valido.")
        }
    }
    
    
    
}
