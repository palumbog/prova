//
//  FirebaseManager.swift
//  DrugBox
//
//  Created by gpalumbo on 05/07/17.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit
import Firebase

class FirebaseManager: NSObject {
    
    static let sharedInstance = FirebaseManager()
    private override init(){}
    
    var sharedDrugs = [Farmaco]()
    var users = [String]()
    var drug = Farmaco()
    var codici = [String]()
    var conteggioCodici = 0
    var observersPlaceAdded : Bool = false
    var childByAutoID = String()
    
    
    var usersPlace = [String]()
    
    //UsersDrugPlace
    var usersDrugPlace = [String]()
    var drugCode = String()
    
    //getUserDrug
    var userDrug = [String]()
    var userDrugScatoli = [Int]()
    
    //UserMessages
    var userMessages = [Message]()
    var userMessagesChatView = [Message]()
    var userMessagesDictionary = [String:Message]()
    var userMessagesCount = 0
    var firstTime = true
    var wasFirstTime = true
    
    
    
    //Osservo i farmaci nella mia zona
    func observeCodiciProvincia(zona : String){
    
        //Mi prendo tutto il nodo farmaci
        Database.database().reference().child("zonaFarmaci").child(zona).observeSingleEvent(of : .value, with: { (snapshot) in
            // Get user value
            
            if let value = snapshot.value as? NSDictionary{
                //Value è un dizionario con numero di elementi uguale al numero di farmaci in database
                //con chiave i codici dei farmaci e valori un dizionario chiave-valore
                
                
                //Recuperiamo tutte le chiavi
                self.codici = value.allKeys as! [String]
                self.conteggioCodici = self.codici.count
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "CodiciScaricati"), object: nil)
            }else{
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "FarmaciProvincia"), object: nil)
            }
            
        }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    
    //Osservo gli utenti che hanno condiviso un farmaco
    func observeUsers(codice: String) {
        self.users.removeAll()
        Database.database().reference().child("farmaciUsers").observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user value
            let value = snapshot.value as? NSDictionary
            //Value è un dizionario con numero di elementi uguale al numero di farmaci condivisi
            
            
            //Recuperiamo tutte le chiavi
            let keys = value?.allKeys as! [String]
            if(keys.contains(codice)){
                print("Ci sono utenti che hanno quel farmaco")
                let keyUsers = value?[codice] as? NSDictionary
                self.users = keyUsers?.allKeys as! [String]
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "UsersNotification"), object: nil)
            }
            else{
                print("Non ci sono utenti che hanno quel farmaco")
            }
        }
            
            
        ) { (error) in
            print(error.localizedDescription)
        }
    }
    
    func getUsersDrugPlace(drugCode: String,place: String){
        self.drugCode = drugCode
        NotificationCenter.default.addObserver(self, selector: #selector(getUserDrug(_:)), name: NSNotification.Name(rawValue: "UsersPlaceScaricati"), object: nil)
        print("Aggiunta UsersPlaceScaricati")
        
        getUsersPlace(place: place)
    }
    
    func getUsersPlace(place : String){
        usersPlace.removeAll()
        userDrug.removeAll()
        userDrugScatoli.removeAll()
        Database.database().reference().child("provinciaUser").child(place).observeSingleEvent(of: .value, with: { (snapshot) in
            
            if let value = snapshot.value as? NSDictionary{
                self.usersPlace = value.allKeys as! [String]
                print("Postata UsersPlaceScaricati")
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "UsersPlaceScaricati"), object: nil)
                
            }/* C'è sempre qualcuno che ha quel farmaco altrimenti la lista sarebbe vuota
             
             else{
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "UsersPlaceNonScaricati"), object: nil)
            }*/
            
        })
    }
    
    func getUserDrug(_ notification: NSNotification){
        print("Ricevuta UsersPlaceScaricati")
        var i = 0
        for user in usersPlace{
            Database.database().reference().child("usersBox").child(user).child(self.drugCode).observeSingleEvent(of: .value, with: { (snapshot) in
                
                if let value = snapshot.value as? NSDictionary{
                    self.userDrug.append(user)
                    let numScatoli = value["numScatoli"] as! Int
                    self.userDrugScatoli.append(numScatoli)
                    //Prendo anche gli scatoli
                    
                    
                }
                i += 1
                //Lancio notifica se ho controllato che tutti i possibili utenti siano stati controllati
                if(i == self.usersPlace.count){
                    print("Postata UsersAdded")
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "UsersAdded"), object: nil)
                    
                    NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "UsersPlaceScaricati"), object: nil)
                    print("Eliminato UsersPlaceScaricati")
                }
            })
        }
    }
    
    func insertDrug(drug : Drug){
        
        
        Database.database().reference().child("farmaci").child(drug.codeDrug!).setValue([
            
            "codice" : drug.codeDrug!,
            
            "nome" : drug.nameDrug!,
            
            "principio" : drug.activePrincipeDrug!,
            
            "casa" : drug.drugmakerDrug!,
            
            "tipo" : drug.typeDrug!
            ])
    }
    
    func insertBox(drugCode: String, dateExpiring:  NSDate, quantityRemaining: Int,nickname:String){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        let data = dateFormatter.string(from: dateExpiring as Date)
        childByAutoID = Database.database().reference().child("usersBox").child(nickname).child(drugCode).childByAutoId().key
        
        let sharedCode : [String:String] = ["code":childByAutoID]
        
        Database.database().reference().child("usersBox").child(nickname).child(drugCode).child(childByAutoID).setValue([
            "dataScadenza" : data,
            "quantita" : quantityRemaining
            ])
        incrementScatolo(nickname:nickname,drugCode:drugCode)
        //Devo salvare il codice generato automaticamente e associarlo allo scatolo
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "CodeBox"), object: nil,userInfo: sharedCode)
    }
    
    func incrementScatolo(nickname:String,drugCode:String){
        Database.database().reference().child("usersBox").child(nickname).child(drugCode).child("numScatoli").observeSingleEvent(of: .value, with: { (snapshot) in
            
            if (snapshot.value is NSNull){
                Database.database().reference().child("usersBox").child(nickname).child(drugCode).child("numScatoli").setValue(1)
            }
            else{
                let n = snapshot.value as! Int
                let num = n + 1
                Database.database().reference().child("usersBox").child(nickname).child(drugCode).child("numScatoli").setValue(num)
            }
        }
            
            
        ) { (error) in
            print(error.localizedDescription)
        }
    }
    
    func insertZonaFarmaci(zona: String,drugCode:String){
        Database.database().reference().child("zonaFarmaci").child(zona).child(drugCode).observeSingleEvent(of: .value, with: {(snapshot) in
            if (snapshot.value is NSNull){
            Database.database().reference().child("zonaFarmaci").child(zona).child(drugCode).child("numScatoli").setValue(1)
            }
            else{
            self.incrementScatoloZonaFarmaci(zona: zona,drugCode:drugCode)
            }
            })
        { (error) in
            print(error.localizedDescription)
        }
        
    }
    
    func incrementScatoloZonaFarmaci(zona: String,drugCode:String){
        Database.database().reference().child("zonaFarmaci").child(zona).child(drugCode).child("numScatoli").observeSingleEvent(of: .value, with: { (snapshot) in
            print(snapshot.value)
            let n = snapshot.value as! Int
            let num = n + 1
            Database.database().reference().child("zonaFarmaci").child(zona).child(drugCode).child("numScatoli").setValue(num)
            
        }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    func insertUser(nickname : String,provincia : String){
        Database.database().reference().child("users").child(nickname).child("provincia").setValue(provincia)
        Database.database().reference().child("provinciaUser").child(provincia).child(nickname).setValue(true)
    }
    
    func getFarmaco(codice : String) {
        Database.database().reference().child("farmaci").child(codice).observeSingleEvent(of: .value, with: { (snapshot) in
            if let dic = snapshot.value as? NSDictionary{
                self.drug = Farmaco(code: (dic["codice"])! as! String, nome: (dic["nome"])! as! String, ditta: (dic["casa"])! as! String, principio: (dic["principio"])! as! String,quantita: 0,descrizione: (dic["tipo"])! as! String)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "FarmacoScaricato"), object: nil)
            }
        }
            
            
        ) { (error) in
            print(error.localizedDescription)
        }
        
    }
    
    func getFarmaci(_ notification: NSNotification){
        var i = 0
        for _ in codici{
            getFarmaco(codice: codici[i])
            i += 1
        }
    }
    
    func insertFarmaco(_ notification: NSNotification){
        sharedDrugs.append(drug)
        if(conteggioCodici == sharedDrugs.count){
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "FarmaciProvincia"), object: nil)
        }
    }
    
    func observeDrugsPlace(zona : String){
        sharedDrugs.removeAll()
        codici.removeAll()
        if(!observersPlaceAdded){
            NotificationCenter.default.addObserver(self, selector: #selector(insertFarmaco(_:)), name: NSNotification.Name(rawValue: "FarmacoScaricato") , object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(getFarmaci(_:)), name: NSNotification.Name(rawValue: "CodiciScaricati") , object: nil)
            observersPlaceAdded = true
        }
        observeCodiciProvincia(zona: zona)
    }
    
    func searchUser(nickname : String){
        Database.database().reference().child("users").child(nickname).observeSingleEvent(of : .value, with: { (snapshot) in
            // Get user value
            
            if let value = snapshot.value as? NSDictionary{
                
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "UserFound"), object: nil)
            }else{
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "UserNotFound"), object: nil)
            }
            
        }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    func deleteBox(drugCode: String,nickname:String,boxCode : String,zona : String){
        Database.database().reference().child("usersBox").child(nickname).child(drugCode).child("numScatoli").observeSingleEvent(of: .value, with: { (snapshot) in
            let value = snapshot.value as? Int
            if (value == 1){
                Database.database().reference().child("usersBox").child(nickname).child(drugCode).removeValue()
            }
            else{
                Database.database().reference().child("usersBox").child(nickname).child(drugCode).child(boxCode).removeValue()
                Database.database().reference().child("usersBox").child(nickname).child(drugCode).child("numScatoli").setValue(value! - 1)
            }
            self.decrementScatoloZonaFarmaci(zona: zona, drugCode: drugCode)
        }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    func decrementScatoloZonaFarmaci(zona: String,drugCode:String){
        Database.database().reference().child("zonaFarmaci").child(zona).child(drugCode).child("numScatoli").observeSingleEvent(of: .value, with: { (snapshot) in
            let n = snapshot.value as! Int
            if (n == 1){
                Database.database().reference().child("zonaFarmaci").child(zona).child(drugCode).removeValue()
            }else{
                let num = n - 1
                Database.database().reference().child("zonaFarmaci").child(zona).child(drugCode).child("numScatoli").setValue(num)
            }
            
            
        }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    func sendMessage(from : String,to : String,message : String){
        let timestamp : Int = Int(NSDate().timeIntervalSince1970)
        var ref = Database.database().reference().child("chat")
        let key = ref.childByAutoId().key
        ref.child(key).setValue([
            "from" : from,
            "to" : to,
            "message" : message,
            "timestamp" : timestamp
            ])
        //ref = Database.database().reference().child("userMessages").child(from)
        
        ref = Database.database().reference().child("userMessages")
        
        ref.updateChildValues([
            "\(from)/\(key)" : true,
            "\(to)/\(key)" : true
            ])
        /*
        ref.updateChildValues([
            key : true
            ])*/
    }
    
    func getUserMessages(user : String){
    
        self.userMessages.removeAll()
        self.userMessagesChatView.removeAll()
        
        let ref = Database.database().reference().child("userMessages").child(user)
        /*
        ref.observeSingleEvent(of: .value, with: { (snapshot) in
            if let data = snapshot.value as? NSDictionary{
                let keys = data.allKeys as! [String]
                self.userMessagesCount = keys.count
                for key in keys {
                    self.getMessage(id: key,user: user)
                }
                
                
            }
            
            
        })*/
        ref.observe(.childAdded, with: { (snapshot) in
            
            
        self.getMessage(id: snapshot.key, user: user)
            /*
                        if(self.firstTime){
                self.userMessages.removeAll()
                self.userMessagesChatView.removeAll()
                self.userMessagesCount = keys.count
                self.firstTime = false
            }else{
                self.userMessagesCount += 1
            }
            
            for key in keys {
                self.getMessage(id: key,user: user)
            }*/
        }) { (error) in
            print(error)
        }
        /*
        ref.observe(.childAdded, with: { (snapshot) in
            print(snapshot)
             let data = snapshot.value as? NSDictionary
                
                let keys = data?.allKeys as! [String]
                if(self.firstTime){
                    self.userMessages.removeAll()
                    self.userMessagesChatView.removeAll()
                    self.userMessagesCount = keys.count
                    self.firstTime = false
                }else{
                    self.userMessagesCount += 1
                }
                
                for key in keys {
                    self.getMessage(id: key,user: user)
                }
                
                
            
        })*/
    }
    
    func getMessage(id : String,user : String){
        let ref = Database.database().reference().child("chat").child(id)
        ref.observeSingleEvent(of: .value, with: { (snapshot) in
            if let data = snapshot.value as? NSDictionary{
                let message = Message()
                let to = data["to"] as! String
                let mes = data["message"] as! String
                let timestamp = data["timestamp"] as! Int
                let from = data["from"] as! String
                message.to = to
                message.message = mes
                message.timestamp = timestamp
                message.from = from
                
                self.userMessagesChatView.append(message)
                
                
                self.insertInDictionary(message: message, user: user)
                
                self.userMessages = Array(self.userMessagesDictionary.values)
                self.userMessages.sort(by: { (m1, m2) -> Bool in
                    return m1.timestamp! > m2.timestamp!
                })
                
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "MessagesDownloaded"), object: nil)
                
                /*
                if(self.wasFirstTime){
                    if(self.userMessagesChatView.count == self.userMessagesCount){
                        self.userMessages = Array(self.userMessagesDictionary.values)
                        self.userMessages.sort(by: { (m1, m2) -> Bool in
                            return m1.timestamp! > m2.timestamp!
                        })
                        self.wasFirstTime = false
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "MessagesDownloaded"), object: nil)
                        
                    }
                }
                else{
                    self.userMessages = Array(self.userMessagesDictionary.values)
                    self.userMessages.sort(by: { (m1, m2) -> Bool in
                        return m1.timestamp! > m2.timestamp!
                    })
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "MessagesDownloaded"), object: nil)
                }*/
                
                
            }
        })
    }
    
    func insertInDictionary(message: Message,user: String){
        let chatPartner = message.getChatPartner()
        
        if(self.isLastMessage(message: message,chatPartner:chatPartner)){
            self.userMessagesDictionary[chatPartner] = message
        }
        
        
    }
    
    func isLastMessage(message: Message,chatPartner: String) -> Bool{
        if let mex = userMessagesDictionary[chatPartner]{
            if(mex.timestamp! < message.timestamp!){
                return true
            }
            return false
        }else{
            return true
        }
    }
    
    func setIsFirstTime(isFirstTime: Bool){
        self.firstTime = isFirstTime
    }
    func setWasFirstTime(isFirstTime: Bool){
        self.firstTime = isFirstTime
    }
    

}
