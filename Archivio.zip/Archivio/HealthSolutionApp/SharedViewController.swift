//
//  SharedViewController.swift
//  DrugBox
//
//  Created by gpalumbo on 13/07/17.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit
import Toast_Swift

class SharedViewController: UIViewController, UITableViewDelegate,UITableViewDataSource, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var provinciaTextField: UITextField!
    @IBOutlet weak var sharedTable: UITableView!
    
    
    var currentLocation : String?
    let provinciaPicker = UIPickerView()
    var province = [String]()
    let onlineController = MenuController.onlineController
    let manager = MenuController.manager
    var userOK : Bool = false
    
    var user : User?
    var trovato : Bool = false
    
    override func viewDidLoad() {
        
        
        super.viewDidLoad()
        getArrayFromJson()
        navigationItem.title = "Farmaci Online"
        //navigationController?.navigationBar.backgroundColor = ChatCell.blueColor
        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 203/255, green: 228/255, blue: 249/255, alpha: 1)
        
        
        //userOK = checkUser()
        provinciaPicker.delegate = self
        provinciaPicker.dataSource = self
        provinciaTextField.inputView = provinciaPicker
        sharedTable.tableFooterView = UIView()
        
        
        
        userOK = checkUser()
        if userOK {
            currentLocation = user?.provincia
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        NotificationCenter.default.addObserver(self, selector: #selector(farmaciScaricati(_:)), name: NSNotification.Name(rawValue: "FarmaciProvincia"), object: nil)
        if(userOK){
            onlineController.observeDrugsPlace(zona: (user?.provincia)!)
            let index = province.index(of: currentLocation!)
            self.provinciaPicker.selectRow(index!, inComponent: 0, animated: false)
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self)
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(userOK){
            let count = MenuController.onlineController.sharedDrugs.count
            if(count>0){
                ordinaShared()
                trovato = true
                return count
            }else{
                trovato = false
            }
            
        }
            return 1
        
    }
    
    private func ordinaShared(){
        let array = MenuController.onlineController.sharedDrugs.sorted(by: sortFarmaco)
        MenuController.onlineController.sharedDrugs = array
    }
    private func sortFarmaco(f1 : Farmaco,f2 : Farmaco) -> Bool{
        return f1.nome < f2.nome
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = sharedTable.dequeueReusableCell(withIdentifier: "sharedCell", for: indexPath) as! SharedTableViewCell
        if(userOK){
            if(trovato){
                let drug = MenuController.onlineController.sharedDrugs[indexPath.row]
                cell.nameLabel.text = "\(drug.nome)" + " " + "\(drug.descrizione)"
            }else{
                cell.nameLabel.text = "Nessun farmaco condiviso qui"
            }
            
        }else{
            cell.nameLabel.text = "Completa il profilo nel menu"
        }
        return cell
    }
    
    func checkUser() -> Bool{
        guard let user = manager.getUser() else{
            self.navigationController?.view.makeToast("Crea il profilo nel menu per questa funzione")
            return false
        }
        self.user = user
        provinciaTextField.text = user.provincia
        return true
    }
    
    func farmaciScaricati(_ notification: NSNotification){
        DispatchQueue.main.async{
            self.sharedTable.reloadData()
        }
    }
    
    func getArrayFromJson()  {
        if let path = Bundle.main.path(forResource: "province", ofType: "json"){
            do {
                let jsonData = try NSData(contentsOfFile: path, options: NSData.ReadingOptions.mappedIfSafe)
                do {
                    let jsonResult: NSDictionary = try JSONSerialization.jsonObject(with: jsonData as Data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    if let province : [String] = jsonResult["province"] as? [String] {
                        self.province = province
                    }
                } catch {}
            } catch {}
        }
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView,
                    numberOfRowsInComponent component: Int) -> Int {
        return province.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return province[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        provinciaTextField.text = province[row]
        if(userOK){
            onlineController.observeDrugsPlace(zona: provinciaTextField.text!)
        }
        self.view.endEditing(false)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        //print("SEGUE IDENTIFIER : \(segue.identifier!)")
        
        switch segue.identifier! {
            
        case "showUsers" :
            currentLocation = province[provinciaPicker.selectedRow(inComponent: 0)]
            let dstView = segue.destination as!  UsersTableViewController
            let current = sharedTable.indexPathForSelectedRow?.row
            dstView.codice = MenuController.onlineController.sharedDrugs[current!].code
            dstView.onlineController = MenuController.onlineController
            dstView.manager = MenuController.manager
            dstView.zona = provinciaTextField.text!
            break
        default:
            preconditionFailure("Segue non valido.")
        }
    }
    
}
