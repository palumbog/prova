//
//  ChatLogController.swift
//  DrugBox
//
//  Created by Admin on 25/07/17.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit
import Firebase

class ChatLogController: UICollectionViewController, UICollectionViewDelegateFlowLayout,UITextFieldDelegate{
    
    var user: String?
    var manager : DataManager?
    var onlineManager : FirebaseManager?
    let inputTextField = UITextField()
    let idCell = "idCell"
    var messages = [Message]()
    
    
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        NotificationCenter.default.removeObserver(self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView?.alwaysBounceVertical = true
        collectionView?.contentInset = UIEdgeInsets(top: 8, left: 0, bottom: 8, right: 0)
        initMessages()
        //collectionView?.scrollIndicatorInsets = UIEdgeInsets(top: 0, left: 0, bottom: 50, right: 0)
        collectionView?.backgroundColor = UIColor.white
        collectionView?.register(ChatCell.self, forCellWithReuseIdentifier: idCell)
        
        collectionView?.keyboardDismissMode = .interactive
        
        navigationItem.title = user
        //setupInputComponents()
        //setupKeyboardObservers()
        NotificationCenter.default.addObserver(self, selector: #selector(messaggiScaricati(_:)), name: NSNotification.Name(rawValue: "MessagesDownloaded"), object: nil)
    }
    
    override var canBecomeFirstResponder: Bool {return true}
    
    lazy var  inputContainerView : UIView = {
        let containerView = UIView()
        containerView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: 50)
        containerView.backgroundColor = UIColor.white
        
        //SendButton
        let sendButton = UIButton(type: .system)
        sendButton.setTitle("Invia", for: .normal)
        sendButton.translatesAutoresizingMaskIntoConstraints = false
        containerView.addSubview(sendButton)
        
        //x,y,w,h
        sendButton.rightAnchor.constraint(equalTo: containerView.rightAnchor).isActive = true
        sendButton.centerYAnchor.constraint(equalTo: containerView.centerYAnchor).isActive = true
        sendButton.widthAnchor.constraint(equalToConstant: 80).isActive = true
        sendButton.heightAnchor.constraint(equalTo: containerView.heightAnchor).isActive = true
        
        sendButton.addTarget(self, action: #selector(inviaPressed), for: .touchUpInside)
        
        //InputTextField
        
        self.inputTextField.placeholder = "Inserisci messaggio..."
        self.inputTextField.translatesAutoresizingMaskIntoConstraints = false
        containerView.addSubview(self.inputTextField)
        //x,y,w,h
        self.inputTextField.leftAnchor.constraint(equalTo: containerView.leftAnchor,constant: 8).isActive = true
        self.inputTextField.centerYAnchor.constraint(equalTo: containerView.centerYAnchor).isActive = true
        self.inputTextField.rightAnchor.constraint(equalTo: sendButton.leftAnchor).isActive = true
        self.inputTextField.heightAnchor.constraint(equalTo: containerView.heightAnchor).isActive = true
        
        //Separator
        let separator = UIView()
        separator.backgroundColor = UIColor.black
        containerView.addSubview(separator)
        separator.translatesAutoresizingMaskIntoConstraints = false
        //x,y,w,h
        separator.leftAnchor.constraint(equalTo: containerView.leftAnchor).isActive = true
        separator.rightAnchor.constraint(equalTo: containerView.rightAnchor).isActive = true
        separator.heightAnchor.constraint(equalToConstant: 1).isActive = true
        separator.bottomAnchor.constraint(equalTo: containerView.topAnchor).isActive = true
        
        
        return containerView
    }()
    
    override var inputAccessoryView: UIView?{
        get {
            return inputContainerView
        }
    }
    
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        collectionView?.collectionViewLayout.invalidateLayout()
    }
    
    func setupKeyboardObservers(){
        NotificationCenter.default.addObserver(self, selector: #selector(handleKeyboardWillShow), name: .UIKeyboardWillShow , object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleKeyboardWillHide), name: .UIKeyboardWillHide , object: nil)
        
    }
    
    func handleKeyboardWillShow(notification : NSNotification){
        let keyboardHeight : CGFloat?
        if let keyboardFrame: NSValue = notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue {
            let keyboardRectangle = keyboardFrame.cgRectValue
            keyboardHeight = keyboardRectangle.height
            
            
            let keyboardDuration = notification.userInfo?[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber
            let keyboardDurationValue = keyboardDuration?.doubleValue
            
            containerViewBottomAnchor?.constant = -keyboardHeight!
            UIView.animate(withDuration: keyboardDurationValue!, animations: {self.view.layoutIfNeeded()})
        }
    }
    
    func handleKeyboardWillHide(notification : NSNotification){
        let keyboardDuration = notification.userInfo?[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber
        let keyboardDurationValue = keyboardDuration?.doubleValue
        containerViewBottomAnchor?.constant = 0
        UIView.animate(withDuration: keyboardDurationValue!, animations: {self.view.layoutIfNeeded()})
    }
    
    var containerViewBottomAnchor : NSLayoutConstraint?
    
    func setupInputComponents(){
        
        inputTextField.delegate = self
        //Container
        let containerView = UIView()
        containerView.backgroundColor = UIColor.white
        containerView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(containerView)
        
        //x,y,w,h
        containerView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        containerViewBottomAnchor = containerView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        containerViewBottomAnchor?.isActive = true
        containerView.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        containerView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        //SendButton
        let sendButton = UIButton(type: .system)
        sendButton.setTitle("Invia", for: .normal)
        sendButton.translatesAutoresizingMaskIntoConstraints = false
        containerView.addSubview(sendButton)
        
        //x,y,w,h
        sendButton.rightAnchor.constraint(equalTo: containerView.rightAnchor).isActive = true
        sendButton.centerYAnchor.constraint(equalTo: containerView.centerYAnchor).isActive = true
        sendButton.widthAnchor.constraint(equalToConstant: 80).isActive = true
        sendButton.heightAnchor.constraint(equalTo: containerView.heightAnchor).isActive = true
        
        sendButton.addTarget(self, action: #selector(inviaPressed), for: .touchUpInside)
        
        //InputTextField
        
        inputTextField.placeholder = "Inserisci messaggio..."
        inputTextField.translatesAutoresizingMaskIntoConstraints = false
        containerView.addSubview(inputTextField)
        //x,y,w,h
        inputTextField.leftAnchor.constraint(equalTo: containerView.leftAnchor,constant: 8).isActive = true
        inputTextField.centerYAnchor.constraint(equalTo: containerView.centerYAnchor).isActive = true
        inputTextField.rightAnchor.constraint(equalTo: sendButton.leftAnchor).isActive = true
        inputTextField.heightAnchor.constraint(equalTo: containerView.heightAnchor).isActive = true
        
        //Separator
        let separator = UIView()
        separator.backgroundColor = UIColor.black
        containerView.addSubview(separator)
        separator.translatesAutoresizingMaskIntoConstraints = false
        //x,y,w,h
        separator.leftAnchor.constraint(equalTo: containerView.leftAnchor).isActive = true
        separator.rightAnchor.constraint(equalTo: containerView.rightAnchor).isActive = true
        separator.heightAnchor.constraint(equalToConstant: 1).isActive = true
        separator.bottomAnchor.constraint(equalTo: containerView.topAnchor).isActive = true
        
        
    }
    func inviaPressed(){
        guard inputTextField.text != nil || inputTextField.text != "" else{
            return
        }
        onlineManager?.sendMessage(from : (manager?.getUser()?.nickname)!,to : user!,message : inputTextField.text!)
        
        self.inputTextField.text = nil
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return messages.count
    }
    
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        var cell = collectionView.dequeueReusableCell(withReuseIdentifier: idCell, for: indexPath) as! ChatCell
        let message = messages[indexPath.row]
        
        cell.textView.text = message.message
        
        setupCell(cell:cell,message:message)
        
        cell.bubbleWidthAnchor?.constant = altezzaStimata(text: message.message!).width + 30
        
        return cell
        
    }
    
    private func setupCell(cell : ChatCell,message : Message){
        if message.from == user{
            //Bubble grigia
            cell.bubbleView.backgroundColor = UIColor.lightGray
            cell.textView.textColor = UIColor.black
            cell.bubbleViewRightAnchor?.isActive = false
            cell.bubbleViewLeftAnchor?.isActive = true
        }else{
            //Bubble blu
            cell.bubbleView.backgroundColor = ChatCell.blueColor
            cell.textView.textColor = UIColor.white
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        var height : CGFloat = 80
        //Stimo altezza cella
        if let text = messages[indexPath.row].message{
            height = altezzaStimata(text: text).height
        }
        
        return CGSize(width: view.frame.width, height: height + 20)
    }
    
    
    
    private func altezzaStimata(text: String) -> CGRect{
        let size = CGSize(width: 200, height: 1000)
        let options = NSStringDrawingOptions.usesFontLeading.union(.usesLineFragmentOrigin)
        return NSString(string: text).boundingRect(with: size, options: options, attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 16)], context: nil)
    }
    
    func initMessages(){
        filterMessages()
        orderMessages()
    }
    
    
    func filterMessages(){
        let messagess = (onlineManager?.userMessagesChatView)!
        for message in messagess{
            if message.getChatPartner() == user{
                messages.append(message)
            }
        }
    }
    
    func orderMessages(){
        messages.sort { (m1, m2) -> Bool in
            return m1.timestamp! < m2.timestamp!
        }
    }
    
    func isMyMessage(message: Message) -> Bool{
        return message.to == user
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        inviaPressed()
        return true
    }
    func messaggiScaricati(_ notification: NSNotification){
        messages.removeAll()
        initMessages()
        
        DispatchQueue.main.async{
            self.collectionView?.reloadData()
        }
    }
    
    
}
