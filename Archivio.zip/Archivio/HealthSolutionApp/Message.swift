//
//  Message.swift
//  DrugBox
//
//  Created by Admin on 27/07/17.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import UIKit

class Message: NSObject {
    var message,from,to : String?
    var timestamp : Int?
    var manager = MenuController.manager
    
    func getChatPartner() -> String{
        var chatPartner = String()
        if(manager.getUser()?.nickname == to){
            chatPartner = from!
        }else{
            chatPartner = to!
        }
        return chatPartner
    }
}
