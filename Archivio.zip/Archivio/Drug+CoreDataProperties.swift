//
//  Drug+CoreDataProperties.swift
//  
//
//  Created by gpalumbo on 20/07/17.
//
//

import Foundation
import CoreData


extension Drug {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Drug> {
        return NSFetchRequest<Drug>(entityName: "Drug")
    }

    @NSManaged public var activePrincipeDrug: String?
    @NSManaged public var codeDrug: String?
    @NSManaged public var drugmakerDrug: String?
    @NSManaged public var nameDrug: String?
    @NSManaged public var quantityDrug: Int16
    @NSManaged public var typeDrug: String?
    @NSManaged public var boxes: NSSet?

}

// MARK: Generated accessors for boxes
extension Drug {

    @objc(addBoxesObject:)
    @NSManaged public func addToBoxes(_ value: Box)

    @objc(removeBoxesObject:)
    @NSManaged public func removeFromBoxes(_ value: Box)

    @objc(addBoxes:)
    @NSManaged public func addToBoxes(_ values: NSSet)

    @objc(removeBoxes:)
    @NSManaged public func removeFromBoxes(_ values: NSSet)

}
