//
//  ImageStoreCore+CoreDataClass.swift
//  DrugBox
//
//  Created by Alberto Capriolo on 10/03/2017.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import Foundation
import CoreData

@objc(ImageStoreCore)
public class ImageStoreCore: NSManagedObject {

}
