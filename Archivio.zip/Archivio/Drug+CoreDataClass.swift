//
//  Drug+CoreDataClass.swift
//  HealthSolutionApp
//
//  Created by Alberto Capriolo on 02/03/2017.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import Foundation
import CoreData

@objc(Drug)
public class Drug: NSManagedObject {

}
