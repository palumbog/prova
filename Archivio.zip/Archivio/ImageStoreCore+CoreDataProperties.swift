//
//  ImageStoreCore+CoreDataProperties.swift
//  DrugBox
//
//  Created by Alberto Capriolo on 10/03/2017.
//  Copyright © 2017 Alberto Capriolo. All rights reserved.
//

import Foundation
import CoreData


extension ImageStoreCore {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ImageStoreCore> {
        return NSFetchRequest<ImageStoreCore>(entityName: "ImageStoreCore");
    }

    @NSManaged public var key: String?
    @NSManaged public var image: NSData?

}
